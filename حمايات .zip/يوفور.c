// 4A Protection Tool - Extracted Offsets
// Library: libUE4.so
// Date: 2026-03-26 16:15:22.445856
// Total keywords: 89


// ========== Monitor ==========
MemoryPatch::createWithHex("libUE4.so", 0x3D3B694, "49 6E 69 74 4D 6F 6E 69").Modify(); // InitMonitorDataPtr
MemoryPatch::createWithHex("libUE4.so", 0x3DAC00C, "41 74 6D 6F 73 50 6C 75").Modify(); // AtmosPlugin atmos_5_1_2 monitoring.
MemoryPatch::createWithHex("libUE4.so", 0x3DD14B4, "70 6F 73 73 69 62 6C 79").Modify(); // possibly monitoring progress in detail with the -vv flag.
MemoryPatch::createWithHex("libUE4.so", 0x3E0C130, "4D 6F 76 65 53 70 65 65").Modify(); // MoveSpeedParamMonitorStrategy
MemoryPatch::createWithHex("libUE4.so", 0x3E5F138, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\ShadowTrackerExtra\UI\UIManager\UIMonitorManager.cpp

// ========== Tss ==========
MemoryPatch::createWithHex("libUE4.so", 0x3C57BC8, "4F 6E 52 53 54 53 53 70").Modify(); // OnRSTSSpeechToTextCallback
MemoryPatch::createWithHex("libUE4.so", 0x3C8ED40, "53 65 74 4D 65 73 68 53").Modify(); // SetMeshSectionCastsShadow
MemoryPatch::createWithHex("libUE4.so", 0x3CAB040, "42 72 6F 61 64 63 61 73").Modify(); // BroadcastClientsSimulateMeleeDamage
MemoryPatch::createWithHex("libUE4.so", 0x3CAB064, "42 72 6F 61 64 63 61 73").Modify(); // BroadcastClientsSimulateRadialDamageDie
MemoryPatch::createWithHex("libUE4.so", 0x3CC192C, "42 72 6F 61 64 63 61 73").Modify(); // BroadcastClientsSimulateVehicleDamageDie
MemoryPatch::createWithHex("libUE4.so", 0x3CCC45C, "49 73 50 72 65 73 65 74").Modify(); // IsPresetsSearch
MemoryPatch::createWithHex("libUE4.so", 0x3CEE414, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ShootMultiEnergyAccumulateProjectileBulletsSimulate
MemoryPatch::createWithHex("libUE4.so", 0x3D17480, "4E 6F 74 69 66 79 43 6C").Modify(); // NotifyClientsStartStride
MemoryPatch::createWithHex("libUE4.so", 0x3D89EB8, "42 72 6F 61 64 63 61 73").Modify(); // BroadcastClientsSimulateAirAttackDamage
MemoryPatch::createWithHex("libUE4.so", 0x3D8A85C, "53 65 74 53 53 53 4D 42").Modify(); // SetSSSMBoundsZOffset
MemoryPatch::createWithHex("libUE4.so", 0x3DB8B18, "54 73 73 4D 67 72 00 50").Modify(); // TssMgr
MemoryPatch::createWithHex("libUE4.so", 0x3E2A770, "53 68 6F 77 50 6C 61 74").Modify(); // ShowPlatformSpecificAchievementsScreen
MemoryPatch::createWithHex("libUE4.so", 0x3E49640, "45 52 65 70 6C 61 63 65").Modify(); // EReplaceSlot::EReplaceType_BootsSlot
MemoryPatch::createWithHex("libUE4.so", 0x3E4C6B8, "54 73 73 53 64 6B 41 6E").Modify(); // TssSdkAntiData
MemoryPatch::createWithHex("libUE4.so", 0x3E606D4, "44 65 76 69 61 74 69 6F").Modify(); // DeviationInfo_NoTss
MemoryPatch::createWithHex("libUE4.so", 0x3E6A0FC, "45 78 69 74 48 6F 72 73").Modify(); // ExitHorseSocketsSetting
MemoryPatch::createWithHex("libUE4.so", 0x3EA73EC, "52 53 54 53 53 70 65 65").Modify(); // RSTSSpeechToText
MemoryPatch::createWithHex("libUE4.so", 0x3EBBF38, "62 54 73 73 44 61 74 61").Modify(); // bTssDataCheck
MemoryPatch::createWithHex("libUE4.so", 0x3EE80EC, "47 65 74 54 53 53 47 61").Modify(); // GetTSSGameId
MemoryPatch::createWithHex("libUE4.so", 0x3F39410, "50 58 53 63 65 6E 65 3A").Modify(); // PXScene::fetchResultsStart: fetchResultsStart() called illegally! It must be called after advance() or simulate()
MemoryPatch::createWithHex("libUE4.so", 0x3FB6544, "20 51 54 53 73 74 76 00").Modify(); //  QTSstv

// ========== Cheat ==========
MemoryPatch::createWithHex("libUE4.so", 0x3C5DA90, "41 6E 74 69 43 68 65 61").Modify(); // AntiCheatRandValue3
MemoryPatch::createWithHex("libUE4.so", 0x3C71FCC, "43 6C 69 65 6E 74 43 68").Modify(); // ClientCheatWalk
MemoryPatch::createWithHex("libUE4.so", 0x3CA029C, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\Development\GMCheat\GMCheatLevel.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3CAF0E4, "41 6E 74 69 43 68 65 61").Modify(); // AntiCheatDetailData
MemoryPatch::createWithHex("libUE4.so", 0x3CB62B4, "43 68 65 61 74 42 65 67").Modify(); // CheatBeginPlay
MemoryPatch::createWithHex("libUE4.so", 0x3CE0C80, "41 6E 74 69 43 68 65 61").Modify(); // AntiCheatRandValue1
MemoryPatch::createWithHex("libUE4.so", 0x3CEC97C, "43 68 65 61 74 43 68 65").Modify(); // CheatCheckSumFailed
MemoryPatch::createWithHex("libUE4.so", 0x3CEDE08, "62 43 68 65 61 74 46 6C").Modify(); // bCheatFlying
MemoryPatch::createWithHex("libUE4.so", 0x3CF1824, "43 68 65 61 74 54 79 70").Modify(); // CheatType1
MemoryPatch::createWithHex("libUE4.so", 0x3CFEEC8, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\ShadowTrackerExtra\Weapons\AntiCheat\AntiCheatUtils.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3D17CA4, "41 6E 74 69 43 68 65 61").Modify(); // AntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3D30D0C, "56 65 68 69 63 6C 65 41").Modify(); // VehicleAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3D66648, "43 6C 69 65 6E 74 43 68").Modify(); // ClientCheatGhost
MemoryPatch::createWithHex("libUE4.so", 0x3D8B344, "62 53 68 6F 75 6C 64 52").Modify(); // bShouldReportAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3D8CF50, "41 6E 74 69 43 68 65 61").Modify(); // AntiCheatMaxOmega
MemoryPatch::createWithHex("libUE4.so", 0x3E0A85C, "62 45 6E 61 62 6C 65 53").Modify(); // bEnableServerAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3E360EC, "4D 6F 76 65 43 68 65 61").Modify(); // MoveCheatAntiStrategy3
MemoryPatch::createWithHex("libUE4.so", 0x3E41208, "62 48 61 73 53 74 61 6E").Modify(); // bHasStandbyCheatTriggered
MemoryPatch::createWithHex("libUE4.so", 0x3E58A2C, "54 65 73 74 47 4D 43 68").Modify(); // TestGMCheatHiggs
MemoryPatch::createWithHex("libUE4.so", 0x3E61F1C, "53 68 6F 76 65 6C 41 6E").Modify(); // ShovelAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3EF80B0, "49 73 52 75 6E 6E 69 6E").Modify(); // IsRunningForAnticheat

// ========== Report ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCE984, "5F 5A 4E 36 47 43 6C 6F").Modify(); // _ZN6GCloud10CrashSight21CrashSightMobileAgent19ConfigCrashReporterEi
MemoryPatch::createWithHex("libUE4.so", 0x3C576BC, "47 65 74 42 75 67 52 65").Modify(); // GetBugReporter
MemoryPatch::createWithHex("libUE4.so", 0x3C5828C, "45 52 65 61 6C 74 69 6D").Modify(); // ERealtimeReportType
MemoryPatch::createWithHex("libUE4.so", 0x3C5ECAC, "47 4D 53 65 6E 64 44 61").Modify(); // GMSendDailyTaskReport
MemoryPatch::createWithHex("libUE4.so", 0x3C6A70C, "62 45 6E 61 62 6C 65 44").Modify(); // bEnableDSErrorLogReport
MemoryPatch::createWithHex("libUE4.so", 0x3C6DA24, "41 6C 6C 53 74 61 72 52").Modify(); // AllStarReportData
MemoryPatch::createWithHex("libUE4.so", 0x3C701F0, "50 6C 65 61 73 65 20 72").Modify(); // Please report it to me at: jseward@bzip.org.  If this happened
MemoryPatch::createWithHex("libUE4.so", 0x3C7DB48, "53 65 74 74 69 6E 67 52").Modify(); // SettingReportItem_IntIntMap
MemoryPatch::createWithHex("libUE4.so", 0x3C81760, "53 65 72 76 65 72 52 65").Modify(); // ServerReportProtection
MemoryPatch::createWithHex("libUE4.so", 0x3C8184C, "4F 6E 43 6C 69 65 6E 74").Modify(); // OnClientReportPeerVisualFieldActorList
MemoryPatch::createWithHex("libUE4.so", 0x3C91988, "52 65 70 6F 72 74 49 6E").Modify(); // ReportInterval
MemoryPatch::createWithHex("libUE4.so", 0x3C98850, "54 50 65 72 66 6F 72 50").Modify(); // TPerforPlatDataReport
MemoryPatch::createWithHex("libUE4.so", 0x3C98AE8, "4F 6E 55 49 53 74 61 74").Modify(); // OnUIStatReport__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3C998A8, "48 61 73 56 65 68 69 63").Modify(); // HasVehicleReportEntry
MemoryPatch::createWithHex("libUE4.so", 0x3CAE698, "4F 62 6A 20 72 65 70 6F").Modify(); // Obj report mark
MemoryPatch::createWithHex("libUE4.so", 0x3CAE910, "47 65 74 50 6C 61 79 65").Modify(); // GetPlayerStatusReportInfo
MemoryPatch::createWithHex("libUE4.so", 0x3CAEE84, "52 65 70 6F 72 74 53 63").Modify(); // ReportScore
MemoryPatch::createWithHex("libUE4.so", 0x3CDA48C, "52 65 70 6F 72 74 43 72").Modify(); // ReportCrashLogWithFDNum
MemoryPatch::createWithHex("libUE4.so", 0x3CEE580, "62 55 73 65 41 6E 74 69").Modify(); // bUseAntiDataReportFilterCheck
MemoryPatch::createWithHex("libUE4.so", 0x3CF1E14, "47 65 74 4D 61 78 57 65").Modify(); // GetMaxWeaponReportNum
MemoryPatch::createWithHex("libUE4.so", 0x3D00DA0, "4C 61 73 74 54 69 6D 65").Modify(); // LastTimeReportEuipmentFlow
MemoryPatch::createWithHex("libUE4.so", 0x3D0809C, "4E 65 74 77 6F 72 6B 52").Modify(); // NetworkReportActor
MemoryPatch::createWithHex("libUE4.so", 0x3D08130, "52 65 70 6F 72 74 54 61").Modify(); // ReportTaskExtInfo
MemoryPatch::createWithHex("libUE4.so", 0x3D19868, "45 6E 61 62 6C 65 52 65").Modify(); // EnableReportGameSettingLevel
MemoryPatch::createWithHex("libUE4.so", 0x3D1CFCC, "50 65 72 66 52 65 70 6F").Modify(); // PerfReportSetLabel
MemoryPatch::createWithHex("libUE4.so", 0x3D2BD10, "43 68 65 63 6B 4E 65 65").Modify(); // CheckNeedReportChatMsgInfo
MemoryPatch::createWithHex("libUE4.so", 0x3D30CD8, "62 46 6F 72 63 65 52 65").Modify(); // bForceReportException
MemoryPatch::createWithHex("libUE4.so", 0x3D46B44, "53 74 61 74 65 52 65 70").Modify(); // StateReportData
MemoryPatch::createWithHex("libUE4.so", 0x3D46C50, "52 65 70 6F 72 74 41 69").Modify(); // ReportAimFlow
MemoryPatch::createWithHex("libUE4.so", 0x3D48EE8, "52 65 70 6F 72 74 54 79").Modify(); // ReportType
MemoryPatch::createWithHex("libUE4.so", 0x3D57F7C, "52 65 70 6F 72 74 50 72").Modify(); // ReportPriority
MemoryPatch::createWithHex("libUE4.so", 0x3D5A668, "52 50 43 5F 52 65 70 6C").Modify(); // RPC_Replay_RefreshSettingReportData
MemoryPatch::createWithHex("libUE4.so", 0x3D5C9C0, "43 68 65 63 6B 4E 65 65").Modify(); // CheckNeedReportSignMsgInfo
MemoryPatch::createWithHex("libUE4.so", 0x3D5D2E8, "53 65 76 65 72 52 65 70").Modify(); // SeverReportSimulateDrag
MemoryPatch::createWithHex("libUE4.so", 0x3D77BD0, "52 65 70 6F 72 74 46 69").Modify(); // ReportFileForAbroad
MemoryPatch::createWithHex("libUE4.so", 0x3D8B344, "62 53 68 6F 75 6C 64 52").Modify(); // bShouldReportAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3D8B48C, "54 65 61 6D 6D 61 74 65").Modify(); // TeammateDisappearReportDistance
MemoryPatch::createWithHex("libUE4.so", 0x3D8EA7C, "52 65 70 6F 72 74 54 61").Modify(); // ReportTaskData
MemoryPatch::createWithHex("libUE4.so", 0x3DA10AC, "62 52 65 70 6F 72 74 00").Modify(); // bReport
MemoryPatch::createWithHex("libUE4.so", 0x3DB1514, "53 65 74 47 61 6D 65 45").Modify(); // SetGameEndReportData
MemoryPatch::createWithHex("libUE4.so", 0x3DB7B9C, "53 65 72 76 65 72 52 65").Modify(); // ServerReportExceptionData
MemoryPatch::createWithHex("libUE4.so", 0x3DB8B5C, "47 61 6D 65 42 75 67 52").Modify(); // GameBugReporter
MemoryPatch::createWithHex("libUE4.so", 0x3DBED14, "45 52 65 70 6F 72 74 65").Modify(); // EReporterLineStyle::Type
MemoryPatch::createWithHex("libUE4.so", 0x3DCDBC0, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\Client\Tools\BugReporter.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3DCE980, "45 52 65 61 6C 74 69 6D").Modify(); // ERealtimeReportType::CharMove1
MemoryPatch::createWithHex("libUE4.so", 0x3DE15A8, "4F 6E 43 6C 69 65 6E 74").Modify(); // OnClientReportPeerVisualFieldAcotrList
MemoryPatch::createWithHex("libUE4.so", 0x3DF9610, "4F 6E 52 65 66 72 65 73").Modify(); // OnRefreshReportSettingConfig
MemoryPatch::createWithHex("libUE4.so", 0x3E08998, "53 65 74 52 65 70 6F 72").Modify(); // SetReportChatMsgInfo
MemoryPatch::createWithHex("libUE4.so", 0x3E0C1CC, "49 73 45 6E 61 62 6C 65").Modify(); // IsEnableReportMrpcsInCircleFlow
MemoryPatch::createWithHex("libUE4.so", 0x3E1E508, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ReportFloatArrayUnreliable
MemoryPatch::createWithHex("libUE4.so", 0x3E1EE40, "4F 6E 52 65 70 6F 72 74").Modify(); // OnReportPlayerEquipmentFlow
MemoryPatch::createWithHex("libUE4.so", 0x3E3B77C, "52 65 70 6F 72 74 46 69").Modify(); // ReportFirebaseEventWithString
MemoryPatch::createWithHex("libUE4.so", 0x3E3BBD4, "56 6F 69 63 65 53 64 6B").Modify(); // VoiceSdkQuitLbsRoomReportEnable
MemoryPatch::createWithHex("libUE4.so", 0x3E47200, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportEvent(std::string eventName, bool isRealTime) end
MemoryPatch::createWithHex("libUE4.so", 0x3E60AB0, "52 65 70 6F 72 74 49 6E").Modify(); // ReportIntArrayData
MemoryPatch::createWithHex("libUE4.so", 0x3E67E04, "4F 6E 52 65 70 6F 72 74").Modify(); // OnReportSettingConfigStart
MemoryPatch::createWithHex("libUE4.so", 0x3E685C8, "56 65 68 69 63 6C 65 50").Modify(); // VehicleProtectionReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E68614, "56 65 68 69 63 6C 65 52").Modify(); // VehicleReportEntry
MemoryPatch::createWithHex("libUE4.so", 0x3E6B05C, "45 72 72 6F 72 52 65 70").Modify(); // ErrorReporting.EmptyBox
MemoryPatch::createWithHex("libUE4.so", 0x3E6B074, "45 72 72 6F 72 52 65 70").Modify(); // ErrorReporting.BackgroundColor
MemoryPatch::createWithHex("libUE4.so", 0x3E78A60, "43 68 61 72 61 63 74 65").Modify(); // CharacterStateReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E7C3D0, "52 65 70 6F 72 74 4F 70").Modify(); // ReportOpPanelExceptionData
MemoryPatch::createWithHex("libUE4.so", 0x3E88CC8, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportPurchase(std::string purchaseName,std::string currencyCode, std::string expense, bool isRealTime) start
MemoryPatch::createWithHex("libUE4.so", 0x3E8B658, "47 65 74 43 68 61 72 61").Modify(); // GetCharacterStateReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E8B674, "52 65 70 6F 72 74 44 61").Modify(); // ReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E9E5C0, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportEvent(std::string eventName,std::vector<KVPair> cEventList, bool isRealTime) start
MemoryPatch::createWithHex("libUE4.so", 0x3E9E62C, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportPurchase(std::string purchaseName,std::string currencyCode, std::string expense, bool isRealTime) end
MemoryPatch::createWithHex("libUE4.so", 0x3EA72B8, "53 65 74 43 72 61 73 68").Modify(); // SetCrashContextReportLevel
MemoryPatch::createWithHex("libUE4.so", 0x3EB78A0, "53 65 74 54 65 73 74 54").Modify(); // SetTestTaskReportData
MemoryPatch::createWithHex("libUE4.so", 0x3EC9478, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportRevenue(std::string eventToken, std::string currency, std::string value, std::map<std::string, std::string> params, std::string extraJson ) end
MemoryPatch::createWithHex("libUE4.so", 0x3EE64F0, "52 65 70 6F 72 74 54 65").Modify(); // ReportTeammateClientLocationError
MemoryPatch::createWithHex("libUE4.so", 0x3EFDCC8, "45 6E 61 62 6C 65 52 65").Modify(); // EnableReportVoiceSdkEvent
MemoryPatch::createWithHex("libUE4.so", 0x3F093E8, "4F 6E 52 65 70 6F 72 74").Modify(); // OnReportData
MemoryPatch::createWithHex("libUE4.so", 0x3F27A10, "63 6F 6E 74 61 63 74 52").Modify(); // contactReportThreshold
MemoryPatch::createWithHex("libUE4.so", 0x3F2AFA8, "49 3A 5C 64 65 76 5F 65").Modify(); // I:\dev_engine\DevOps\UE4181\Engine\Source\ThirdParty\PhysX\PhysX_3.4\Source\SimulationController\src\ScContactReportBuffer.h
MemoryPatch::createWithHex("libUE4.so", 0x3F2BF98, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_SCENE_QUERY
MemoryPatch::createWithHex("libUE4.so", 0x3F2F410, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_TRIGGER_NOTIFY
MemoryPatch::createWithHex("libUE4.so", 0x3F31AE0, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_CONSTRAINT_BREAK_NOTIFY
MemoryPatch::createWithHex("libUE4.so", 0x3F370D0, "43 6F 6E 74 61 63 74 52").Modify(); // ContactReportThreshold
MemoryPatch::createWithHex("libUE4.so", 0x3F3C078, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_CONTACT_NOTIFY
MemoryPatch::createWithHex("libUE4.so", 0x3F3E940, "53 63 53 63 65 6E 65 2E").Modify(); // ScScene.lostTouchReports
MemoryPatch::createWithHex("libUE4.so", 0x3F4B400, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairReport]
MemoryPatch::createWithHex("libUE4.so", 0x3F4B550, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairContactReportData]
MemoryPatch::createWithHex("libUE4.so", 0x3F4B6B0, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairReport*]
MemoryPatch::createWithHex("libUE4.so", 0x3F4EC80, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Bp::BroadPhasePairReport]
MemoryPatch::createWithHex("libUE4.so", 0x3F4F710, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairReport*]

// ========== Server ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCB8D4, "5F 5A 4E 33 55 51 4D 38").Modify(); // _ZN3UQM8UQMCrash19SetCrashLogObserverEPNS_19UQMCrashLogObserverE
MemoryPatch::createWithHex("libUE4.so", 0x2DCEB58, "5F 5A 4E 34 69 6E 74 6C").Modify(); // _ZN4intl10Compliance21SetComplianceObserverEPNS_18ComplianceObserverE
MemoryPatch::createWithHex("libUE4.so", 0x3C4F018, "49 67 6E 6F 72 65 56 61").Modify(); // IgnoreVaultingServerCheck
MemoryPatch::createWithHex("libUE4.so", 0x3C51ACC, "4F 6E 52 65 70 5F 53 65").Modify(); // OnRep_ServerBulletSpeed
MemoryPatch::createWithHex("libUE4.so", 0x3C56784, "53 65 72 76 65 72 4A 75").Modify(); // ServerJump_Vehicle4W
MemoryPatch::createWithHex("libUE4.so", 0x3C56874, "53 65 72 76 65 72 55 6E").Modify(); // ServerUnlink
MemoryPatch::createWithHex("libUE4.so", 0x3C58FA0, "53 65 6E 64 4D 6F 76 65").Modify(); // SendMoveStatusToServer
MemoryPatch::createWithHex("libUE4.so", 0x3C59924, "62 43 6C 69 65 6E 74 52").Modify(); // bClientResolveServerPenetration
MemoryPatch::createWithHex("libUE4.so", 0x3C5D77C, "53 65 72 76 65 72 43 68").Modify(); // ServerChangeName
MemoryPatch::createWithHex("libUE4.so", 0x3C67478, "53 65 72 76 65 72 42 75").Modify(); // ServerBulletSpeed
MemoryPatch::createWithHex("libUE4.so", 0x3C678BC, "53 65 72 76 65 72 5F 55").Modify(); // Server_UpdateInputTransform
MemoryPatch::createWithHex("libUE4.so", 0x3C68144, "53 65 72 76 65 72 56 61").Modify(); // ServerVaultBlockHeightEnd
MemoryPatch::createWithHex("libUE4.so", 0x3C69670, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerSpectatorKickFromGame
MemoryPatch::createWithHex("libUE4.so", 0x3C69BF8, "49 73 49 6E 53 65 72 76").Modify(); // IsInServerAuthorizeState
MemoryPatch::createWithHex("libUE4.so", 0x3C6B188, "53 65 72 76 65 72 46 69").Modify(); // ServerFinishCreateWeaponTime
MemoryPatch::createWithHex("libUE4.so", 0x3C6BD60, "45 56 65 68 69 63 6C 65").Modify(); // EVehicleCorrectionReason::ServerVehicleIsInAir
MemoryPatch::createWithHex("libUE4.so", 0x3C7AE6C, "42 61 63 6B 70 61 63 6B").Modify(); // BackpackObserverItem
MemoryPatch::createWithHex("libUE4.so", 0x3C7E45C, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMoveData
MemoryPatch::createWithHex("libUE4.so", 0x3C7FF58, "53 65 72 76 65 72 53 65").Modify(); // ServerSetControlRotation
MemoryPatch::createWithHex("libUE4.so", 0x3C80E08, "62 54 75 72 6E 4F 6E 6C").Modify(); // bTurnOnlyOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3C81760, "53 65 72 76 65 72 52 65").Modify(); // ServerReportProtection
MemoryPatch::createWithHex("libUE4.so", 0x3C8BD8C, "53 65 72 76 65 72 53 65").Modify(); // ServerSetReplicatedEventWithPayload
MemoryPatch::createWithHex("libUE4.so", 0x3C99950, "62 50 6C 61 79 4F 6E 53").Modify(); // bPlayOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3CA81B4, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMoveMode
MemoryPatch::createWithHex("libUE4.so", 0x3CA8278, "43 72 65 61 74 65 54 68").Modify(); // CreateThunderOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3CAA2F0, "54 6F 6C 65 72 61 74 65").Modify(); // TolerateLocationDiffSqAtServer
MemoryPatch::createWithHex("libUE4.so", 0x3CAADC8, "52 50 43 5F 53 65 72 76").Modify(); // RPC_ServerSetDeformedRotation
MemoryPatch::createWithHex("libUE4.so", 0x3CAB400, "53 65 72 76 65 72 43 6F").Modify(); // ServerControlRotation
MemoryPatch::createWithHex("libUE4.so", 0x3CAC27C, "46 72 69 65 6E 64 4F 62").Modify(); // FriendObserverDetails
MemoryPatch::createWithHex("libUE4.so", 0x3CAD504, "41 6C 6C 6F 77 65 64 4D").Modify(); // AllowedMaxHitDistanceSqAtServer
MemoryPatch::createWithHex("libUE4.so", 0x3CAE588, "52 65 73 6F 6C 76 65 44").Modify(); // ResolveDNSWithServerIP
MemoryPatch::createWithHex("libUE4.so", 0x3CAEE30, "49 4D 53 44 4B 5F 53 45").Modify(); // IMSDK_SERVER_HELP_SCHEME_TEST
MemoryPatch::createWithHex("libUE4.so", 0x3CAF394, "45 4F 62 73 65 72 76 65").Modify(); // EObserverEnemyTraceType::Both
MemoryPatch::createWithHex("libUE4.so", 0x3CB0978, "53 65 72 76 65 72 53 65").Modify(); // ServerSetRisingInput
MemoryPatch::createWithHex("libUE4.so", 0x3CB80BC, "53 65 72 76 65 72 45 6E").Modify(); // ServerEndAbility
MemoryPatch::createWithHex("libUE4.so", 0x3CBE910, "45 43 75 73 74 6F 6D 43").Modify(); // ECustomCndEventType::OnFireHitServer
MemoryPatch::createWithHex("libUE4.so", 0x3CBECA8, "53 65 72 76 65 72 5F 52").Modify(); // Server_RPC_DebugINFO
MemoryPatch::createWithHex("libUE4.so", 0x3CBFFEC, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMoveClientRoll
MemoryPatch::createWithHex("libUE4.so", 0x3CC00D8, "4F 6E 56 61 75 6C 74 46").Modify(); // OnVaultFailFromServer__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3CC1058, "48 61 6E 64 6C 65 53 65").Modify(); // HandleServerCheckPlaceBuilding
MemoryPatch::createWithHex("libUE4.so", 0x3CC75BC, "53 65 72 76 65 72 53 65").Modify(); // ServerSetCamelMaxWalkSpeed
MemoryPatch::createWithHex("libUE4.so", 0x3CCBCEC, "56 65 72 69 66 79 53 65").Modify(); // VerifyServerSkillData
MemoryPatch::createWithHex("libUE4.so", 0x3CCD4A8, "47 6F 74 20 75 6E 65 78").Modify(); // Got unexpected imap-server response
MemoryPatch::createWithHex("libUE4.so", 0x3CD68D8, "53 65 72 76 65 72 55 73").Modify(); // ServerUserMoveCmd
MemoryPatch::createWithHex("libUE4.so", 0x3CD7210, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_SetCurScopeFov
MemoryPatch::createWithHex("libUE4.so", 0x3CD7CD8, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMontageTrackPosition
MemoryPatch::createWithHex("libUE4.so", 0x3CD8210, "53 77 61 70 57 65 61 70").Modify(); // SwapWeaponByPropSlotOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3CDAC40, "49 4D 53 44 4B 5F 53 45").Modify(); // IMSDK_SERVER_HELP
MemoryPatch::createWithHex("libUE4.so", 0x3CDD30C, "53 65 72 76 65 72 52 65").Modify(); // ServerReleaseCharacter
MemoryPatch::createWithHex("libUE4.so", 0x3CDD5BC, "62 4F 6E 6C 79 43 65 68").Modify(); // bOnlyCehckInServer
MemoryPatch::createWithHex("libUE4.so", 0x3CE901C, "49 73 53 65 72 76 65 72").Modify(); // IsServerWithObject
MemoryPatch::createWithHex("libUE4.so", 0x3CEB294, "43 6C 69 65 6E 74 53 65").Modify(); // ClientServerFlyTimeTorelate
MemoryPatch::createWithHex("libUE4.so", 0x3CEB5D4, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_JoinCoopEmote
MemoryPatch::createWithHex("libUE4.so", 0x3CEB68C, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMoveCacheCountOver
MemoryPatch::createWithHex("libUE4.so", 0x3CEB948, "53 65 72 76 65 72 43 72").Modify(); // ServerCrossWallJumpTolerance
MemoryPatch::createWithHex("libUE4.so", 0x3CEC360, "53 65 72 76 65 72 44 6F").Modify(); // ServerDoJump
MemoryPatch::createWithHex("libUE4.so", 0x3CEC8E4, "43 61 63 68 65 53 65 72").Modify(); // CacheServerMoves
MemoryPatch::createWithHex("libUE4.so", 0x3CED2A4, "53 65 72 76 65 72 43 75").Modify(); // ServerCurHealth
MemoryPatch::createWithHex("libUE4.so", 0x3CEDB50, "53 65 6E 64 54 6F 53 65").Modify(); // SendToServerChangeCameraMode
MemoryPatch::createWithHex("libUE4.so", 0x3CEE414, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ShootMultiEnergyAccumulateProjectileBulletsSimulate
MemoryPatch::createWithHex("libUE4.so", 0x3CEE91C, "46 6F 72 63 65 53 79 6E").Modify(); // ForceSyncAllClientsBulletsNumOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3CEEE34, "53 65 6E 64 54 72 69 67").Modify(); // SendTriggerEventToServer
MemoryPatch::createWithHex("libUE4.so", 0x3CEFC30, "53 79 6E 63 41 76 61 74").Modify(); // SyncAvatarMusicIDClientToServer
MemoryPatch::createWithHex("libUE4.so", 0x3CEFF1C, "53 65 72 76 65 72 46 6F").Modify(); // ServerForceLinkTo
MemoryPatch::createWithHex("libUE4.so", 0x3CF0D10, "53 65 74 53 65 72 76 65").Modify(); // SetServerInfo
MemoryPatch::createWithHex("libUE4.so", 0x3CF9B6C, "53 53 4C 33 5F 53 45 4E").Modify(); // SSL3_SEND_SERVER_HELLO
MemoryPatch::createWithHex("libUE4.so", 0x3CFA7A0, "55 45 6E 75 6D 73 2E 45").Modify(); // UEnums.EObjectMark = {OBJECTMARK_NOMARKS = 0,OBJECTMARK_Saved = 4,OBJECTMARK_TagImp = 8,OBJECTMARK_TagExp = 16,OBJECTMARK_NotForClient = 32,OBJECTMARK_NotForServer = 64,OBJECTMARK_NotAlwaysLoadedForEditorGame = 128,OBJECTMARK_EditorOnly = 256,OBJECTMARK_ALLMARKS = -1,}
MemoryPatch::createWithHex("libUE4.so", 0x3D01EE4, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMoveClientMovementBase
MemoryPatch::createWithHex("libUE4.so", 0x3D07284, "46 72 69 65 6E 64 4F 62").Modify(); // FriendObserversDetails
MemoryPatch::createWithHex("libUE4.so", 0x3D08070, "53 65 72 76 65 72 52 65").Modify(); // ServerRepListDispatch
MemoryPatch::createWithHex("libUE4.so", 0x3D091E4, "45 45 6E 64 53 70 65 63").Modify(); // EEndSpecialMoveReason::EndSMReason_ServerCorrection
MemoryPatch::createWithHex("libUE4.so", 0x3D0C5BC, "62 4E 6F 74 46 6F 72 43").Modify(); // bNotForClientOrServer
MemoryPatch::createWithHex("libUE4.so", 0x3D0D94C, "53 65 72 76 65 72 43 68").Modify(); // ServerCheckClientPossession
MemoryPatch::createWithHex("libUE4.so", 0x3D17E08, "53 65 72 76 65 72 52 50").Modify(); // ServerRPC_InterruptCoopVault
MemoryPatch::createWithHex("libUE4.so", 0x3D190F8, "53 65 72 76 65 72 53 65").Modify(); // ServerSetTargetLocAndRot
MemoryPatch::createWithHex("libUE4.so", 0x3D1FDDC, "53 65 72 76 65 72 53 77").Modify(); // ServerSwoopDown
MemoryPatch::createWithHex("libUE4.so", 0x3D2019C, "53 65 72 76 65 72 4F 6E").Modify(); // ServerOnExitDrift
MemoryPatch::createWithHex("libUE4.so", 0x3D27ECC, "53 65 72 76 65 72 5F 49").Modify(); // Server_InstanceByHp
MemoryPatch::createWithHex("libUE4.so", 0x3D2C69C, "62 45 6E 61 62 6C 65 4F").Modify(); // bEnableOnDedicatedServer
MemoryPatch::createWithHex("libUE4.so", 0x3D2DF90, "53 65 72 76 65 72 4D 61").Modify(); // ServerMarkCustom
MemoryPatch::createWithHex("libUE4.so", 0x3D2E2C0, "53 65 72 76 65 72 53 65").Modify(); // ServerSendGameStartFlow
MemoryPatch::createWithHex("libUE4.so", 0x3D2F340, "53 65 72 76 65 72 53 65").Modify(); // ServerSetMovementState
MemoryPatch::createWithHex("libUE4.so", 0x3D30720, "53 65 74 53 70 65 63 69").Modify(); // SetSpecialFixShootTypeOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3D31D5C, "53 65 72 76 65 72 4A 75").Modify(); // ServerJump
MemoryPatch::createWithHex("libUE4.so", 0x3D31DA4, "53 65 6E 64 43 6C 69 65").Modify(); // SendClientMoveToServerOverLapUseRoot
MemoryPatch::createWithHex("libUE4.so", 0x3D31EEC, "4F 62 73 65 72 76 65 72").Modify(); // ObserverController
MemoryPatch::createWithHex("libUE4.so", 0x3D31F58, "56 69 73 75 61 6C 46 69").Modify(); // VisualFieldServerRepInterval
MemoryPatch::createWithHex("libUE4.so", 0x3D41280, "53 65 72 76 65 72 52 65").Modify(); // ServerReservationRequest
MemoryPatch::createWithHex("libUE4.so", 0x3D46000, "53 65 72 76 65 72 5F 48").Modify(); // Server_HitBox_Prone_HalfHeight
MemoryPatch::createWithHex("libUE4.so", 0x3D47CB4, "46 6F 72 63 65 53 77 69").Modify(); // ForceSwitchWeaponBySlotOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3D47E24, "53 65 72 76 65 72 50 6C").Modify(); // ServerPlaceBuildActor
MemoryPatch::createWithHex("libUE4.so", 0x3D497F0, "53 65 72 76 65 72 53 74").Modify(); // ServerStartCreateWeaponTime
MemoryPatch::createWithHex("libUE4.so", 0x3D49ACC, "53 65 72 76 65 72 53 74").Modify(); // ServerStartThrow
MemoryPatch::createWithHex("libUE4.so", 0x3D4A9E4, "62 53 79 6E 63 53 70 65").Modify(); // bSyncSpesificStateToServer
MemoryPatch::createWithHex("libUE4.so", 0x3D4B1A4, "53 65 74 49 6F 73 53 74").Modify(); // SetIosStuckEnableByServerConfig
MemoryPatch::createWithHex("libUE4.so", 0x3D59480, "41 49 41 74 74 72 4F 62").Modify(); // AIAttrObserver
MemoryPatch::createWithHex("libUE4.so", 0x3D59564, "53 65 72 76 65 72 55 70").Modify(); // ServerUpdateMovementInput
MemoryPatch::createWithHex("libUE4.so", 0x3D5DB10, "4F 6E 52 65 70 5F 53 65").Modify(); // OnRep_ServerLastTransformUpdateTimeStamp
MemoryPatch::createWithHex("libUE4.so", 0x3D5DB68, "53 65 72 76 65 72 44 72").Modify(); // ServerDropCurrentWeapon
MemoryPatch::createWithHex("libUE4.so", 0x3D5E26C, "47 65 74 53 65 72 76 65").Modify(); // GetServerStartTime
MemoryPatch::createWithHex("libUE4.so", 0x3D5E458, "53 65 72 76 65 72 52 65").Modify(); // ServerRecycleVehicle
MemoryPatch::createWithHex("libUE4.so", 0x3D5E718, "52 50 43 53 65 72 76 65").Modify(); // RPCServerInput
MemoryPatch::createWithHex("libUE4.so", 0x3D5E804, "41 64 6A 75 73 74 53 65").Modify(); // AdjustServerParachuteLanded
MemoryPatch::createWithHex("libUE4.so", 0x3D5EB08, "53 65 72 76 65 72 43 68").Modify(); // ServerChangeStatePCFromClient
MemoryPatch::createWithHex("libUE4.so", 0x3D5F494, "49 73 49 6E 41 69 72 5F").Modify(); // IsInAir_bServerCheck
MemoryPatch::createWithHex("libUE4.so", 0x3D5F978, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_SkillBlackBoardKey
MemoryPatch::createWithHex("libUE4.so", 0x3D60274, "53 65 72 76 65 72 53 70").Modify(); // ServerSprintFactor
MemoryPatch::createWithHex("libUE4.so", 0x3D6029C, "4F 6E 48 69 74 41 74 53").Modify(); // OnHitAtServer
MemoryPatch::createWithHex("libUE4.so", 0x3D68628, "53 65 72 76 65 72 4E 6F").Modify(); // ServerNotifyRandomSeed
MemoryPatch::createWithHex("libUE4.so", 0x3D69AEC, "45 72 72 6F 72 20 61 63").Modify(); // Error accept()ing server connect
MemoryPatch::createWithHex("libUE4.so", 0x3D69D10, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server tkt skew
MemoryPatch::createWithHex("libUE4.so", 0x3D76C44, "53 65 6E 64 54 6F 53 65").Modify(); // SendToServerUnmannedVehicleRecall
MemoryPatch::createWithHex("libUE4.so", 0x3D78274, "49 4D 53 44 4B 5F 53 45").Modify(); // IMSDK_SERVER_UNIFIED_ACCOUNT_BACKUP_TEST
MemoryPatch::createWithHex("libUE4.so", 0x3D79DF8, "62 53 74 6F 70 4D 6F 76").Modify(); // bStopMoveAfterServerForceEndSM
MemoryPatch::createWithHex("libUE4.so", 0x3D7D508, "53 65 72 76 65 72 57 6F").Modify(); // ServerWorldTimeSecondsDelta
MemoryPatch::createWithHex("libUE4.so", 0x3D8051C, "54 4C 53 31 5F 43 48 45").Modify(); // TLS1_CHECK_SERVERHELLO_TLSEXT
MemoryPatch::createWithHex("libUE4.so", 0x3D86F90, "55 49 4E 6F 74 69 66 79").Modify(); // UINotifyCallbackOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3D89190, "52 50 43 5F 4E 65 74 4D").Modify(); // RPC_NetMulticast_SetUpOrDownOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3D893EC, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerResponseInteractEmoteReq
MemoryPatch::createWithHex("libUE4.so", 0x3D898AC, "53 65 72 76 65 72 49 6D").Modify(); // ServerImpactZSlopeRatio
MemoryPatch::createWithHex("libUE4.so", 0x3D89988, "53 65 72 76 65 72 41 63").Modify(); // ServerAccumulateErrorBurstDistance2DRatio
MemoryPatch::createWithHex("libUE4.so", 0x3D89D48, "52 65 71 53 65 72 76 65").Modify(); // ReqServerChangeWaitingKickState
MemoryPatch::createWithHex("libUE4.so", 0x3D8A0E8, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ChangeToShootGrenade
MemoryPatch::createWithHex("libUE4.so", 0x3D8A108, "53 65 72 76 65 72 53 65").Modify(); // ServerSetRepCharAnimData
MemoryPatch::createWithHex("libUE4.so", 0x3D8B5B8, "53 65 74 43 75 72 72 65").Modify(); // SetCurrentBulletNumInClipOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3D8CA38, "53 65 72 76 65 72 52 65").Modify(); // ServerReqQuickSwitchSeat
MemoryPatch::createWithHex("libUE4.so", 0x3D8DDD0, "49 73 4F 62 73 65 72 76").Modify(); // IsObserver
MemoryPatch::createWithHex("libUE4.so", 0x3D8DF0C, "47 65 74 5A 6F 6E 65 53").Modify(); // GetZoneServerDelay
MemoryPatch::createWithHex("libUE4.so", 0x3D8F138, "53 65 72 76 65 72 45 78").Modify(); // ServerExitVehicle
MemoryPatch::createWithHex("libUE4.so", 0x3D96108, "73 73 6C 33 20 65 78 74").Modify(); // ssl3 ext invalid servername
MemoryPatch::createWithHex("libUE4.so", 0x3D96FBC, "55 45 6E 75 6D 73 2E 45").Modify(); // UEnums.EFunctionFlags = {FUNC_None = 0,FUNC_Final = 1,FUNC_RequiredAPI = 2,FUNC_BlueprintAuthorityOnly = 4,FUNC_BlueprintCosmetic = 8,FUNC_Net = 64,FUNC_NetReliable = 128,FUNC_NetRequest = 256,FUNC_Exec = 512,FUNC_Native = 1024,FUNC_Event = 2048,FUNC_NetResponse = 4096,FUNC_Static = 8192,FUNC_NetMulticast = 16384,FUNC_MulticastDelegate = 65536,FUNC_Public = 131072,FUNC_Private = 262144,FUNC_Protected = 524288,FUNC_Delegate = 1048576,FUNC_NetServer = 2097152,FUNC_HasOutParms = 4194304,FUNC_HasDefaults = 8388608,FUNC_NetClient = 16777216,FUNC_DLLImport = 33554432,FUNC_BlueprintCallable = 67108864,FUNC_BlueprintEvent = 134217728,FUNC_BlueprintPure = 268435456,FUNC_EditorOnly = 536870912,FUNC_Const = 1073741824,FUNC_NetValidate = -2147483648,FUNC_AllFlags = -1,}
MemoryPatch::createWithHex("libUE4.so", 0x3D9E508, "56 73 53 65 72 76 65 72").Modify(); // VsServerNoOldShoot
MemoryPatch::createWithHex("libUE4.so", 0x3D9E6C4, "53 65 72 76 65 72 52 50").Modify(); // ServerRPC_VaultServer
MemoryPatch::createWithHex("libUE4.so", 0x3D9EEA8, "53 65 72 76 65 72 53 74").Modify(); // ServerStartPlayTime
MemoryPatch::createWithHex("libUE4.so", 0x3D9F480, "43 68 61 72 61 63 74 65").Modify(); // CharacterServerMoveDelegate__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3D9FE4C, "53 65 6E 64 43 6C 69 65").Modify(); // SendClientMoveToServerReliabyNew
MemoryPatch::createWithHex("libUE4.so", 0x3DA0410, "42 6F 6F 73 74 43 44 53").Modify(); // BoostCDServerTolerance
MemoryPatch::createWithHex("libUE4.so", 0x3DA6540, "44 65 73 74 72 75 63 74").Modify(); // DestructionRadiusServerCheckScale
MemoryPatch::createWithHex("libUE4.so", 0x3DA7E48, "52 75 6E 74 69 6D 65 2F").Modify(); // Runtime/Engine/Classes\Camera/CameraObserverActor.h
MemoryPatch::createWithHex("libUE4.so", 0x3DAB944, "41 43 43 54 20 72 65 6A").Modify(); // ACCT rejected by server: %03d
MemoryPatch::createWithHex("libUE4.so", 0x3DAC734, "62 49 73 53 65 72 76 65").Modify(); // bIsServerInitiated
MemoryPatch::createWithHex("libUE4.so", 0x3DADBD8, "43 72 65 61 74 69 76 65").Modify(); // CreativeServerDamagedFragmentsDelegate__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3DB0698, "62 53 69 6D 75 6C 61 74").Modify(); // bSimulateJumpingByServer
MemoryPatch::createWithHex("libUE4.so", 0x3DB6260, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ShootSpecialBullet
MemoryPatch::createWithHex("libUE4.so", 0x3DB7B9C, "53 65 72 76 65 72 52 65").Modify(); // ServerReportExceptionData
MemoryPatch::createWithHex("libUE4.so", 0x3DBA268, "42 61 74 74 6C 65 56 6F").Modify(); // BattleVoiceServerURL
MemoryPatch::createWithHex("libUE4.so", 0x3DC6C28, "4C 61 73 74 43 69 72 63").Modify(); // LastCircleCountToDestroyActorOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3DC8C58, "4D 75 6C 74 69 63 61 73").Modify(); // MulticastInteruptPlayEmoteOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3DC8E60, "53 65 72 76 65 72 52 50").Modify(); // ServerRPC_RequestVault
MemoryPatch::createWithHex("libUE4.so", 0x3DCA5EC, "4F 6E 43 68 61 72 61 63").Modify(); // OnCharacterShootHitServerDelegate
MemoryPatch::createWithHex("libUE4.so", 0x3DCAA7C, "53 65 72 76 65 72 52 65").Modify(); // ServerRemoteCreateActor
MemoryPatch::createWithHex("libUE4.so", 0x3DD11B8, "53 65 72 76 65 72 4D 61").Modify(); // ServerMaxAcceleration
MemoryPatch::createWithHex("libUE4.so", 0x3DD7234, "45 47 61 6D 65 70 6C 61").Modify(); // EGameplayAbilityNetExecutionPolicy::ServerOnly
MemoryPatch::createWithHex("libUE4.so", 0x3DDE6E8, "53 65 74 41 74 74 61 63").Modify(); // SetAttachCharacterOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3DDF3A8, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerStopReqInteractEmote
MemoryPatch::createWithHex("libUE4.so", 0x3DE0008, "62 53 65 72 76 65 72 41").Modify(); // bServerAuthorizeByMotionState
MemoryPatch::createWithHex("libUE4.so", 0x3DE13A0, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_NorifyServerClientHasFinishedHandleSpawnWeaponWithWeaponMgr
MemoryPatch::createWithHex("libUE4.so", 0x3DE1460, "53 65 72 76 65 72 43 6F").Modify(); // ServerControlFireBalloonMoveEx
MemoryPatch::createWithHex("libUE4.so", 0x3DEECB0, "46 6F 72 62 69 64 64 65").Modify(); // ForbiddenSyncServerLogConf
MemoryPatch::createWithHex("libUE4.so", 0x3DF17BC, "45 46 6F 72 63 65 48 69").Modify(); // EForceHideStateReason::Server_Default
MemoryPatch::createWithHex("libUE4.so", 0x3DF69C4, "62 52 65 70 42 61 63 6B").Modify(); // bRepBackpackToObserver
MemoryPatch::createWithHex("libUE4.so", 0x3DF77A4, "62 49 6E 44 65 64 69 63").Modify(); // bInDedicateServer
MemoryPatch::createWithHex("libUE4.so", 0x3DF78C8, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerAvatarEquipedDelegate__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3DF82D0, "53 65 72 76 65 72 53 74").Modify(); // ServerStopAndDestroy
MemoryPatch::createWithHex("libUE4.so", 0x3DF8E00, "41 63 74 6F 72 43 68 61").Modify(); // ActorChannelProcessBunchErrorNumThreshold_Server_Global
MemoryPatch::createWithHex("libUE4.so", 0x3DF8F28, "53 65 74 53 65 72 76 65").Modify(); // SetServerTimeInSec
MemoryPatch::createWithHex("libUE4.so", 0x3DFA22C, "4F 62 73 65 72 76 65 72").Modify(); // ObserverPlayerStateClass
MemoryPatch::createWithHex("libUE4.so", 0x3E08834, "53 65 6E 64 43 6C 69 65").Modify(); // SendClientMoveToServerAccurateInternal
MemoryPatch::createWithHex("libUE4.so", 0x3E0A740, "53 65 72 76 65 72 52 50").Modify(); // ServerRPC_RequestJumperVault
MemoryPatch::createWithHex("libUE4.so", 0x3E0A85C, "62 45 6E 61 62 6C 65 53").Modify(); // bEnableServerAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3E0B650, "53 65 72 76 65 72 55 73").Modify(); // ServerUserMoveCmdDual
MemoryPatch::createWithHex("libUE4.so", 0x3E0B7D4, "62 52 65 73 65 74 53 69").Modify(); // bResetSimulateWhenObserver
MemoryPatch::createWithHex("libUE4.so", 0x3E0BF58, "52 65 66 72 65 73 68 50").Modify(); // RefreshPawnVaultTypeServer
MemoryPatch::createWithHex("libUE4.so", 0x3E0C05C, "53 54 53 65 72 76 65 72").Modify(); // STServerUpdateState
MemoryPatch::createWithHex("libUE4.so", 0x3E0C7E8, "47 65 74 53 65 72 76 65").Modify(); // GetServerStartUnixTimestamp
MemoryPatch::createWithHex("libUE4.so", 0x3E0C918, "53 65 72 76 65 72 53 65").Modify(); // ServerSetWalkType
MemoryPatch::createWithHex("libUE4.so", 0x3E0CE68, "4F 6E 52 65 70 4E 6F 74").Modify(); // OnRepNotify_ServerHitEnemyReplicatedData
MemoryPatch::createWithHex("libUE4.so", 0x3E0E588, "62 53 65 72 76 65 72 50").Modify(); // bServerPlayState
MemoryPatch::createWithHex("libUE4.so", 0x3E0E778, "53 65 6E 64 43 6C 69 65").Modify(); // SendClientMoveToServerUnreliably
MemoryPatch::createWithHex("libUE4.so", 0x3E1E508, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ReportFloatArrayUnreliable
MemoryPatch::createWithHex("libUE4.so", 0x3E20144, "53 65 72 76 65 72 52 50").Modify(); // ServerRPC_RequestLifterPrepare
MemoryPatch::createWithHex("libUE4.so", 0x3E20A1C, "53 65 72 76 65 72 55 70").Modify(); // ServerUpdateInput
MemoryPatch::createWithHex("libUE4.so", 0x3E20ABC, "53 65 72 76 65 72 52 65").Modify(); // ServerResponseInteractEmoteReq
MemoryPatch::createWithHex("libUE4.so", 0x3E277DC, "53 65 72 76 65 72 43 6F").Modify(); // ServerConstantFrameRate
MemoryPatch::createWithHex("libUE4.so", 0x3E27DCC, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerLandScapeDestroy
MemoryPatch::createWithHex("libUE4.so", 0x3E28284, "53 65 6E 64 53 65 72 76").Modify(); // SendServerHoverMoveToClient
MemoryPatch::createWithHex("libUE4.so", 0x3E2D3FC, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server tkt expired
MemoryPatch::createWithHex("libUE4.so", 0x3E2DFB0, "53 65 72 76 65 72 43 75").Modify(); // ServerCurrentMontageSetPlayRate
MemoryPatch::createWithHex("libUE4.so", 0x3E308E0, "53 65 72 76 65 72 47 65").Modify(); // ServerGetInstanceIndexsDamaged
MemoryPatch::createWithHex("libUE4.so", 0x3E360A8, "4D 61 78 53 79 6E 63 44").Modify(); // MaxSyncDistanceSqAtServer
MemoryPatch::createWithHex("libUE4.so", 0x3E36A2C, "53 65 72 76 65 72 52 50").Modify(); // ServerRPC_RequestClimberVault
MemoryPatch::createWithHex("libUE4.so", 0x3E37A5C, "62 48 61 73 4E 65 77 43").Modify(); // bHasNewCacheServerMove
MemoryPatch::createWithHex("libUE4.so", 0x3E38034, "53 65 6E 64 41 63 6B 53").Modify(); // SendAckServerMoveToClient
MemoryPatch::createWithHex("libUE4.so", 0x3E39554, "53 65 74 52 65 6C 6F 61").Modify(); // SetReloadTypeOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3E3A078, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_SkillBlackBoardKey_Unreliable
MemoryPatch::createWithHex("libUE4.so", 0x3E3A950, "53 65 72 76 65 72 48 69").Modify(); // ServerHit_Vehicle4W
MemoryPatch::createWithHex("libUE4.so", 0x3E3E22C, "53 65 72 76 65 72 4E 69").Modify(); // ServerNitrogenAccel
MemoryPatch::createWithHex("libUE4.so", 0x3E3EC1C, "62 49 73 53 65 72 76 65").Modify(); // bIsServerToClientRPC
MemoryPatch::createWithHex("libUE4.so", 0x3E41F1C, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerStartedVisualLogger
MemoryPatch::createWithHex("libUE4.so", 0x3E4C2FC, "48 61 6E 64 6C 65 53 65").Modify(); // HandleServerGameReconnected
MemoryPatch::createWithHex("libUE4.so", 0x3E4FB74, "4F 6E 52 65 70 5F 53 65").Modify(); // OnRep_ServerPlayingAvatarMusicID
MemoryPatch::createWithHex("libUE4.so", 0x3E51EF8, "53 65 72 76 65 72 45 78").Modify(); // ServerExitGame
MemoryPatch::createWithHex("libUE4.so", 0x3E563A0, "46 6C 75 73 68 53 65 72").Modify(); // FlushServerMoves
MemoryPatch::createWithHex("libUE4.so", 0x3E60F8C, "47 65 74 47 6C 6F 62 61").Modify(); // GetGlobalWeatherSystemTimeOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3E61AC0, "62 53 65 72 76 65 72 4F").Modify(); // bServerOpen
MemoryPatch::createWithHex("libUE4.so", 0x3E69C74, "53 65 74 53 65 72 76 65").Modify(); // SetServerDiveDirection
MemoryPatch::createWithHex("libUE4.so", 0x3E6CA58, "49 73 53 65 72 76 65 72").Modify(); // IsServer
MemoryPatch::createWithHex("libUE4.so", 0x3E6CD30, "62 41 6C 6C 6F 77 54 69").Modify(); // bAllowTickOnDedicatedServer
MemoryPatch::createWithHex("libUE4.so", 0x3E712C4, "55 45 6E 75 6D 73 2E 45").Modify(); // UEnums.EStrippedData = {None = 0,Editor = 1,Server = 2,All = 255,}
MemoryPatch::createWithHex("libUE4.so", 0x3E776E4, "47 65 74 54 6F 6C 65 72").Modify(); // GetTolerateServerVictmPosTolerateByNetDelay
MemoryPatch::createWithHex("libUE4.so", 0x3E78250, "53 65 72 76 65 72 43 68").Modify(); // ServerCheckIsCanPlay
MemoryPatch::createWithHex("libUE4.so", 0x3E78FD4, "53 65 72 76 65 72 52 65").Modify(); // ServerResponseDuelReq
MemoryPatch::createWithHex("libUE4.so", 0x3E79510, "53 65 72 76 65 72 42 61").Modify(); // ServerBatchMoveDeltaMax
MemoryPatch::createWithHex("libUE4.so", 0x3E7AB04, "49 73 52 65 63 65 6E 74").Modify(); // IsRecentlyCalledServerCMD
MemoryPatch::createWithHex("libUE4.so", 0x3E7AC34, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_NorifyServerAddFirstOpenedPlayerTombBoxes
MemoryPatch::createWithHex("libUE4.so", 0x3E7AC78, "53 65 72 76 65 72 48 61").Modify(); // ServerHandleHitDataArray
MemoryPatch::createWithHex("libUE4.so", 0x3E7B198, "53 65 72 76 65 72 45 6E").Modify(); // ServerEnter
MemoryPatch::createWithHex("libUE4.so", 0x3E7E554, "4F 62 73 65 72 76 65 72").Modify(); // ObserverTime
MemoryPatch::createWithHex("libUE4.so", 0x3E81F74, "44 69 72 65 63 74 6F 72").Modify(); // DirectoriesToAlwaysServerCook
MemoryPatch::createWithHex("libUE4.so", 0x3E8AD98, "4F 62 73 65 72 76 65 72").Modify(); // ObserverCustomAccData
MemoryPatch::createWithHex("libUE4.so", 0x3E8BD6C, "41 64 64 44 72 6F 70 41").Modify(); // AddDropActorServer
MemoryPatch::createWithHex("libUE4.so", 0x3E8D858, "45 4F 62 73 65 72 76 65").Modify(); // EObserverType
MemoryPatch::createWithHex("libUE4.so", 0x3E8DD0C, "53 65 72 76 65 72 53 65").Modify(); // ServerSendGameEndFlow
MemoryPatch::createWithHex("libUE4.so", 0x3E8E598, "53 65 72 76 65 72 42 61").Modify(); // ServerBatchMoveDeltaTimeRateMax
MemoryPatch::createWithHex("libUE4.so", 0x3E8EDD4, "53 65 72 76 65 72 43 61").Modify(); // ServerCancelFollowAircraft
MemoryPatch::createWithHex("libUE4.so", 0x3E8EEE0, "53 65 72 76 65 72 43 75").Modify(); // ServerCurHeath
MemoryPatch::createWithHex("libUE4.so", 0x3E8FD3C, "53 65 72 76 65 72 53 65").Modify(); // ServerSetFreeCameraRotationOnVehicle
MemoryPatch::createWithHex("libUE4.so", 0x3E90524, "52 50 43 53 65 72 76 65").Modify(); // RPCServerSetBrake
MemoryPatch::createWithHex("libUE4.so", 0x3E99750, "53 65 72 76 65 72 54 72").Modify(); // ServerTriggerEvent_WithParams
MemoryPatch::createWithHex("libUE4.so", 0x3EAA470, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerDropActorHit
MemoryPatch::createWithHex("libUE4.so", 0x3EAA804, "62 49 73 43 6C 69 65 6E").Modify(); // bIsClientToServerRPC
MemoryPatch::createWithHex("libUE4.so", 0x3EAD81C, "53 65 72 76 65 72 41 63").Modify(); // ServerAcknowledgePossession
MemoryPatch::createWithHex("libUE4.so", 0x3EB0ACC, "55 45 6E 75 6D 73 2E 45").Modify(); // UEnums.EConfigFileHierarchy = {AbsoluteBase = 0,EngineDirBase = 1,EngineDir_BasePlatform = 2,EngineDirBase_NotForLicensees = 3,EngineDirBase_NoRedist = 4,GameDirDefault = 5,GameDirDedicatedServer = 6,GameDirDefault_NotForLicensees = 7,GameDirDefault_NoRedist = 8,EngineDir_Platform = 9,EngineDir_Platform_NotForLicensees = 10,EngineDir_Platform_NoRedist = 11,GameDir_Platform = 12,GameDir_Platform_NotForLicensees = 13,GameDir_Platform_NoRedist = 14,UserSettingsDir_EngineDir_User = 15,UserDir_User = 16,GameDir_User = 17,NumHierarchyFiles = 18,}
MemoryPatch::createWithHex("libUE4.so", 0x3EB8118, "53 65 72 76 65 72 4D 6F").Modify(); // ServerMoveCompressedMoveFlags
MemoryPatch::createWithHex("libUE4.so", 0x3EB83D0, "62 53 65 72 76 65 72 54").Modify(); // bServerTickCoopVaultCrossWall
MemoryPatch::createWithHex("libUE4.so", 0x3EB9788, "53 65 72 76 65 72 50 6C").Modify(); // ServerPlayerEnterSplineDelegate__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3EB9BF0, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_PlayAircraftAerialShow
MemoryPatch::createWithHex("libUE4.so", 0x3EB9C2C, "53 65 72 76 65 72 4C 61").Modify(); // ServerLaunchCharacter
MemoryPatch::createWithHex("libUE4.so", 0x3EBAC3C, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_NotifyServerEnemyStep
MemoryPatch::createWithHex("libUE4.so", 0x3EBACA8, "53 65 72 76 65 72 54 72").Modify(); // ServerTriggerCharacterCustomEvent
MemoryPatch::createWithHex("libUE4.so", 0x3EBC2DC, "53 65 6E 64 48 69 74 43").Modify(); // SendHitCaveStoneToServer
MemoryPatch::createWithHex("libUE4.so", 0x3EBDDE8, "49 4D 53 44 4B 5F 53 45").Modify(); // IMSDK_SERVER_NOTICE_TEST
MemoryPatch::createWithHex("libUE4.so", 0x3EBEFB4, "52 50 43 5F 53 65 72 76").Modify(); // RPC_ServerGlueHiaPark
MemoryPatch::createWithHex("libUE4.so", 0x3EBEFD4, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerReceiveInvalidFilesInPakLiteDelegate
MemoryPatch::createWithHex("libUE4.so", 0x3ECC12C, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_DoorState
MemoryPatch::createWithHex("libUE4.so", 0x3ECC4FC, "62 45 6E 61 62 6C 65 44").Modify(); // bEnableDebugServer
MemoryPatch::createWithHex("libUE4.so", 0x3ECC854, "4F 6E 52 65 70 5F 53 65").Modify(); // OnRep_ServerHidden
MemoryPatch::createWithHex("libUE4.so", 0x3ECD6A0, "52 65 71 75 65 73 74 52").Modify(); // RequestReplaysFromServer
MemoryPatch::createWithHex("libUE4.so", 0x3ECD8B4, "53 65 72 76 65 72 55 49").Modify(); // ServerUID
MemoryPatch::createWithHex("libUE4.so", 0x3ECD940, "55 70 64 61 74 65 41 64").Modify(); // UpdateAdditionalDataListOnServerAfterSpawn
MemoryPatch::createWithHex("libUE4.so", 0x3ECE750, "53 65 72 76 65 72 46 69").Modify(); // ServerFinishEmote
MemoryPatch::createWithHex("libUE4.so", 0x3ECF718, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_FetchBoundBox
MemoryPatch::createWithHex("libUE4.so", 0x3ECF754, "53 65 72 76 65 72 43 68").Modify(); // ServerCheckEmoteCanPlay
MemoryPatch::createWithHex("libUE4.so", 0x3ECF76C, "53 65 72 76 65 72 46 6F").Modify(); // ServerFollowTeammate
MemoryPatch::createWithHex("libUE4.so", 0x3ED0C7C, "53 65 72 76 65 72 45 71").Modify(); // ServerEquipSpecialAttachActor
MemoryPatch::createWithHex("libUE4.so", 0x3EDABFC, "53 53 4C 20 73 65 72 76").Modify(); // SSL server
MemoryPatch::createWithHex("libUE4.so", 0x3EDBB38, "53 65 72 76 65 72 44 65").Modify(); // ServerDebugStrings
MemoryPatch::createWithHex("libUE4.so", 0x3EDD554, "47 65 74 41 75 74 6F 52").Modify(); // GetAutoRunTestServerIdx
MemoryPatch::createWithHex("libUE4.so", 0x3EDF100, "47 72 6F 75 70 52 65 73").Modify(); // GroupReserveReadPipePackets
MemoryPatch::createWithHex("libUE4.so", 0x3EE6090, "62 53 65 72 76 65 72 44").Modify(); // bServerDetachApplyVelocity
MemoryPatch::createWithHex("libUE4.so", 0x3EE74EC, "44 65 62 75 67 52 65 63").Modify(); // DebugReconnectToClientOnServer
MemoryPatch::createWithHex("libUE4.so", 0x3EEB180, "4F 6E 53 65 72 76 65 72").Modify(); // OnServerTRexStartRoar__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3EEE304, "45 41 75 74 6F 44 6F 72").Modify(); // EAutoDormancyType::ActorTickServer
MemoryPatch::createWithHex("libUE4.so", 0x3EF0210, "4E 65 74 73 63 61 70 65").Modify(); // Netscape SSL server
MemoryPatch::createWithHex("libUE4.so", 0x3EF0410, "53 65 72 76 65 72 20 68").Modify(); // Server hello
MemoryPatch::createWithHex("libUE4.so", 0x3EF61E8, "62 53 69 6D 75 6C 61 74").Modify(); // bSimulateKilledByServer
MemoryPatch::createWithHex("libUE4.so", 0x3EF62F0, "53 65 72 76 65 72 53 65").Modify(); // ServerSetAirAttackLocation
MemoryPatch::createWithHex("libUE4.so", 0x3EF7388, "52 45 54 5F 43 68 61 72").Modify(); // RET_CharacterMovementCacheServerMove2
MemoryPatch::createWithHex("libUE4.so", 0x3EF9EF4, "4D 61 78 53 65 72 76 65").Modify(); // MaxServerMoveDistFrameForPickup
MemoryPatch::createWithHex("libUE4.so", 0x3EF9F14, "4D 61 78 53 65 72 76 65").Modify(); // MaxServerBurstMoveInterval
MemoryPatch::createWithHex("libUE4.so", 0x3EFC5C8, "53 65 72 76 65 72 53 74").Modify(); // ServerStartPrepare
MemoryPatch::createWithHex("libUE4.so", 0x3EFE4D8, "49 4D 53 44 4B 5F 53 45").Modify(); // IMSDK_SERVER_UNIFIED_ACCOUNT_TEST
MemoryPatch::createWithHex("libUE4.so", 0x3F06118, "53 53 4C 5F 50 52 45 50").Modify(); // SSL_PREPARE_SERVERHELLO_TLSEXT
MemoryPatch::createWithHex("libUE4.so", 0x3F06C80, "53 65 72 76 65 72 43 75").Modify(); // ServerCurrentMontageSetNextSectionName
MemoryPatch::createWithHex("libUE4.so", 0x40481E0, "46 55 4E 43 5F 4E 65 74").Modify(); // FUNC_NetServer FUNC_HasOutParms FUNC_HasDefaults
MemoryPatch::createWithHex("libUE4.so", 0x4049474, "41 6C 6C 6F 77 65 64 43").Modify(); // AllowedClasses$AllowPreserveRatio$AllowPrivateAccess

// ========== Path ==========
MemoryPatch::createWithHex("libUE4.so", 0x3C4F828, "44 65 66 61 75 6C 74 4C").Modify(); // DefaultLuaFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3C571DC, "49 73 41 76 61 74 61 72").Modify(); // IsAvatarResPathExist
MemoryPatch::createWithHex("libUE4.so", 0x3C57414, "43 6F 6E 76 65 72 74 47").Modify(); // ConvertGamePathToRelativeFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3C583F8, "62 56 61 6C 69 64 54 6F").Modify(); // bValidTogetherPath
MemoryPatch::createWithHex("libUE4.so", 0x3C5BB44, "50 61 74 68 4F 70 74 69").Modify(); // PathOptimizationInterval
MemoryPatch::createWithHex("libUE4.so", 0x3C5E734, "41 6C 6C 54 79 70 65 73").Modify(); // AllTypesPath
MemoryPatch::createWithHex("libUE4.so", 0x3C5F9D0, "70 72 6F 78 79 20 70 61").Modify(); // proxy path length constraint exceeded
MemoryPatch::createWithHex("libUE4.so", 0x3C61D28, "73 65 61 72 63 68 70 61").Modify(); // searchpath
MemoryPatch::createWithHex("libUE4.so", 0x3C68AE0, "53 49 73 6C 61 6E 64 49").Modify(); // SIslandInteractEmoteTablePath
MemoryPatch::createWithHex("libUE4.so", 0x3C69D70, "53 65 71 75 65 6E 63 65").Modify(); // SequencePath
MemoryPatch::createWithHex("libUE4.so", 0x3C6C8F4, "43 6F 6E 76 65 72 74 50").Modify(); // ConvertPath
MemoryPatch::createWithHex("libUE4.so", 0x3C6D314, "49 6E 54 68 75 6D 62 50").Modify(); // InThumbPath
MemoryPatch::createWithHex("libUE4.so", 0x3C6E7D0, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\Addons\Addons\Skills\SkillActions\UAESkillAction_PredictProjectilePath.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3C71580, "45 50 61 74 68 46 6F 6C").Modify(); // EPathFollowingAction::NoMove
MemoryPatch::createWithHex("libUE4.so", 0x3C78734, "50 69 78 55 49 2D 55 45").Modify(); // PixUI-UE  Log         PxResFileLoad::LoadFile success by game asset path pFilePath:%s
MemoryPatch::createWithHex("libUE4.so", 0x3C7AE40, "49 74 65 6D 41 6E 69 6D").Modify(); // ItemAnimBPPath
MemoryPatch::createWithHex("libUE4.so", 0x3C7BF44, "57 69 64 67 65 74 43 6C").Modify(); // WidgetClassPath
MemoryPatch::createWithHex("libUE4.so", 0x3C7EDA8, "43 68 61 6E 67 65 57 65").Modify(); // ChangeWearingIconPath
MemoryPatch::createWithHex("libUE4.so", 0x3C877D8, "41 73 73 65 74 53 63 61").Modify(); // AssetScanPaths
MemoryPatch::createWithHex("libUE4.so", 0x3C88744, "62 55 73 65 46 69 78 65").Modify(); // bUseFixedBrakingDistanceForPaths
MemoryPatch::createWithHex("libUE4.so", 0x3C8BA0C, "63 61 63 68 65 50 61 74").Modify(); // cachePath
MemoryPatch::createWithHex("libUE4.so", 0x3C8CA28, "63 61 6C 6C 20 46 53 6F").Modify(); // call FSoftObjectPath::GetSubPathString error, argc=%d
MemoryPatch::createWithHex("libUE4.so", 0x3C8CC8C, "4C 75 61 50 61 74 68 54").Modify(); // LuaPathTagMap_Key
MemoryPatch::createWithHex("libUE4.so", 0x3C8DCAC, "47 65 74 50 75 65 72 74").Modify(); // GetPuertsAppIndexPath
MemoryPatch::createWithHex("libUE4.so", 0x3C8EF08, "50 61 74 68 20 63 6F 6E").Modify(); // Path constraint not found:
MemoryPatch::createWithHex("libUE4.so", 0x3C906A8, "4C 69 66 65 53 70 61 6E").Modify(); // LifeSpanDrawAirDropPath
MemoryPatch::createWithHex("libUE4.so", 0x3C90708, "47 65 74 4E 61 76 46 69").Modify(); // GetNavFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3C9E26C, "50 72 65 64 69 63 74 50").Modify(); // PredictProjectilePathResult
MemoryPatch::createWithHex("libUE4.so", 0x3C9E560, "52 65 64 69 72 65 63 74").Modify(); // RedirectSoftObjectPaths
MemoryPatch::createWithHex("libUE4.so", 0x3CA6198, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\ShadowTrackerExtra\Public\AI\Component\NewPathFollowingComponent.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3CA6A6C, "66 50 61 74 68 4C 65 6E").Modify(); // fPathLength
MemoryPatch::createWithHex("libUE4.so", 0x3CA9900, "45 50 6C 61 79 65 72 41").Modify(); // EPlayerAutoNavFindResult::HasPath
MemoryPatch::createWithHex("libUE4.so", 0x3CAA828, "49 73 56 61 6C 69 64 50").Modify(); // IsValidPathIndex
MemoryPatch::createWithHex("libUE4.so", 0x3CAFD00, "41 6C 6C 6F 77 50 61 72").Modify(); // AllowPartialPath
MemoryPatch::createWithHex("libUE4.so", 0x3CB96BC, "63 68 65 63 6B 20 46 53").Modify(); // check FSoftObjectPath nil value
MemoryPatch::createWithHex("libUE4.so", 0x3CB96DC, "63 61 6C 6C 20 46 53 6F").Modify(); // call FSoftObjectPath::GetCurrentTag error, argc=%d
MemoryPatch::createWithHex("libUE4.so", 0x3CBBCB0, "74 68 75 6D 62 50 61 74").Modify(); // thumbPath
MemoryPatch::createWithHex("libUE4.so", 0x3CC1C68, "62 46 6F 72 63 65 53 68").Modify(); // bForceShortestRotationPath
MemoryPatch::createWithHex("libUE4.so", 0x3CC1F14, "4B 69 6C 6C 49 6E 66 6F").Modify(); // KillInfoPath
MemoryPatch::createWithHex("libUE4.so", 0x3CD67F0, "43 75 72 50 61 74 68 49").Modify(); // CurPathIndex
MemoryPatch::createWithHex("libUE4.so", 0x3CD9108, "62 48 61 73 4C 75 61 44").Modify(); // bHasLuaDataPath
MemoryPatch::createWithHex("libUE4.so", 0x3CDA458, "47 65 74 4F 62 62 46 69").Modify(); // GetObbFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3CDAAD8, "50 6B 67 50 61 74 68 73").Modify(); // PkgPaths
MemoryPatch::createWithHex("libUE4.so", 0x3CE6434, "50 69 78 55 49 2D 55 45").Modify(); // PixUI-UE  Warn        asset path error %s
MemoryPatch::createWithHex("libUE4.so", 0x3CE8514, "41 49 41 63 74 69 6E 67").Modify(); // AIActingBPAssitClassPath
MemoryPatch::createWithHex("libUE4.so", 0x3CE8830, "4F 75 74 52 65 66 69 6E").Modify(); // OutRefinedPath
MemoryPatch::createWithHex("libUE4.so", 0x3CE9120, "41 6E 69 6D 42 70 50 61").Modify(); // AnimBpPath
MemoryPatch::createWithHex("libUE4.so", 0x3CEBEE4, "49 63 6F 6E 4F 75 74 53").Modify(); // IconOutScreenIconPath
MemoryPatch::createWithHex("libUE4.so", 0x3CEECF8, "50 61 74 68 50 6F 69 6E").Modify(); // PathPointPlayZoneDistances_Key
MemoryPatch::createWithHex("libUE4.so", 0x3CEF80C, "49 6E 43 6C 61 73 73 50").Modify(); // InClassPath
MemoryPatch::createWithHex("libUE4.so", 0x3CFBC84, "47 65 74 4F 62 6A 65 63").Modify(); // GetObjectAssetPath
MemoryPatch::createWithHex("libUE4.so", 0x3CFFAA0, "49 74 65 6D 50 61 74 68").Modify(); // ItemPathNotExist
MemoryPatch::createWithHex("libUE4.so", 0x3CFFBD8, "4F 70 65 6E 50 61 74 68").Modify(); // OpenPathDebug
MemoryPatch::createWithHex("libUE4.so", 0x3D01DE0, "48 74 74 70 50 6C 61 6E").Modify(); // HttpPlaneBannerRightImgPath
MemoryPatch::createWithHex("libUE4.so", 0x3D06B08, "47 65 74 50 61 73 73 69").Modify(); // GetPassiveDownloadResourcePaths
MemoryPatch::createWithHex("libUE4.so", 0x3D06CB0, "46 69 6E 64 4F 62 6A 65").Modify(); // FindObjectByPath
MemoryPatch::createWithHex("libUE4.so", 0x3D06FAC, "53 65 74 52 65 73 6F 75").Modify(); // SetResourePath
MemoryPatch::createWithHex("libUE4.so", 0x3D0D454, "50 61 74 68 53 74 61 72").Modify(); // PathStart
MemoryPatch::createWithHex("libUE4.so", 0x3D183F0, "49 63 6F 6E 4F 75 74 53").Modify(); // IconOutScreenBGPath
MemoryPatch::createWithHex("libUE4.so", 0x3D1A0B8, "49 6E 41 69 72 44 72 6F").Modify(); // InAirDropPathData
MemoryPatch::createWithHex("libUE4.so", 0x3D1BCC0, "49 6E 53 74 61 72 74 69").Modify(); // InStartingPath
MemoryPatch::createWithHex("libUE4.so", 0x3D2B30C, "47 65 74 57 65 61 70 6F").Modify(); // GetWeaponAvatarDeadBoxAvatarHandlePath
MemoryPatch::createWithHex("libUE4.so", 0x3D2D6B4, "50 61 74 68 4D 6F 76 65").Modify(); // PathMovementComponent
MemoryPatch::createWithHex("libUE4.so", 0x3D2E148, "52 65 70 6C 61 79 55 49").Modify(); // ReplayUIPath
MemoryPatch::createWithHex("libUE4.so", 0x3D38CDC, "4F 6E 4E 61 76 69 67 61").Modify(); // OnNavigationPathUpdated__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3D38D60, "45 4E 61 76 50 61 74 68").Modify(); // ENavPathEvent::Type
MemoryPatch::createWithHex("libUE4.so", 0x3D39AD4, "6C 75 61 50 61 74 68 00").Modify(); // luaPath
MemoryPatch::createWithHex("libUE4.so", 0x3D3B7A0, "4C 69 62 50 61 74 68 00").Modify(); // LibPath
MemoryPatch::createWithHex("libUE4.so", 0x3D413E4, "50 49 58 55 49 5F 44 59").Modify(); // PIXUI_DYLIBPATH
MemoryPatch::createWithHex("libUE4.so", 0x3D5140C, "41 6C 6C 50 61 74 68 4E").Modify(); // AllPathNameMapForLoad
MemoryPatch::createWithHex("libUE4.so", 0x3D566A4, "47 65 74 57 69 64 67 65").Modify(); // GetWidgetPathByPos
MemoryPatch::createWithHex("libUE4.so", 0x3D5F9A0, "53 6B 69 6C 6C 49 44 32").Modify(); // SkillID2LuaOverridePath
MemoryPatch::createWithHex("libUE4.so", 0x3D5F9B8, "53 6B 69 6C 6C 49 44 32").Modify(); // SkillID2LuaOverridePath_Key
MemoryPatch::createWithHex("libUE4.so", 0x3D614DC, "72 65 6C 61 74 69 76 65").Modify(); // relativePath
MemoryPatch::createWithHex("libUE4.so", 0x3D6CE98, "50 69 78 55 49 2D 55 45").Modify(); // PixUI-UE  Error       PxResFileLoad::SaveFileToPath Error,path:%s
MemoryPatch::createWithHex("libUE4.so", 0x3D6EC90, "57 68 65 65 6C 65 64 56").Modify(); // WheeledVehicleNavigatePath
MemoryPatch::createWithHex("libUE4.so", 0x3D6EEB4, "43 75 72 72 65 6E 74 50").Modify(); // CurrentPathInputKey
MemoryPatch::createWithHex("libUE4.so", 0x3D70144, "50 61 74 68 49 6E 70 75").Modify(); // PathInputLocationKey
MemoryPatch::createWithHex("libUE4.so", 0x3D71B24, "62 67 50 61 74 68 00 69").Modify(); // bgPath
MemoryPatch::createWithHex("libUE4.so", 0x3D7790C, "4C 6F 61 64 46 69 6C 65").Modify(); // LoadFileToArrayByFullPath
MemoryPatch::createWithHex("libUE4.so", 0x3D8A5A0, "63 6F 6E 74 65 6E 74 5F").Modify(); // content_file_path
MemoryPatch::createWithHex("libUE4.so", 0x3D8EE10, "4D 6F 76 65 57 69 74 68").Modify(); // MoveWithOutPathFinding
MemoryPatch::createWithHex("libUE4.so", 0x3D9B7F0, "49 6E 64 65 78 4F 66 53").Modify(); // IndexOfSelectedPath
MemoryPatch::createWithHex("libUE4.so", 0x3D9CFBC, "47 65 74 4C 4F 44 4D 61").Modify(); // GetLODMatPaths
MemoryPatch::createWithHex("libUE4.so", 0x3D9F124, "46 72 61 6D 65 44 65 74").Modify(); // FrameDetailsUIPath
MemoryPatch::createWithHex("libUE4.so", 0x3D9F430, "62 46 6F 72 63 65 49 6E").Modify(); // bForceInitNewestPath
MemoryPatch::createWithHex("libUE4.so", 0x3DA091C, "50 61 74 68 4D 6F 76 65").Modify(); // PathMoveFriction
MemoryPatch::createWithHex("libUE4.so", 0x3DA79BC, "47 65 74 41 73 73 65 74").Modify(); // GetAssetByObjectPath
MemoryPatch::createWithHex("libUE4.so", 0x3DA7C74, "45 50 61 74 68 46 6F 6C").Modify(); // EPathFollowingResult::Aborted
MemoryPatch::createWithHex("libUE4.so", 0x3DA7CB0, "45 50 61 74 68 46 6F 6C").Modify(); // EPathFollowingResult
MemoryPatch::createWithHex("libUE4.so", 0x3DAF1F8, "70 72 65 70 61 72 65 20").Modify(); // prepare to load %s (id %s) from rootPath %s
MemoryPatch::createWithHex("libUE4.so", 0x3DBBA70, "46 61 69 6C 45 6E 64 50").Modify(); // FailEndPoint_EffectPath
MemoryPatch::createWithHex("libUE4.so", 0x3DC98DC, "51 75 65 72 79 4E 65 65").Modify(); // QueryNeedAsyncLoadClassPathList
MemoryPatch::createWithHex("libUE4.so", 0x3DC9C08, "4F 6E 52 65 70 5F 43 75").Modify(); // OnRep_CurrentPathIndex
MemoryPatch::createWithHex("libUE4.so", 0x3DCE024, "66 75 6C 6C 50 61 74 68").Modify(); // fullPath
MemoryPatch::createWithHex("libUE4.so", 0x3DCE1E0, "56 69 62 72 61 74 65 41").Modify(); // VibrateAssetTablePath
MemoryPatch::createWithHex("libUE4.so", 0x3DCED74, "55 73 69 6E 67 4E 65 74").Modify(); // UsingNetObjectPathNameMappingCSV
MemoryPatch::createWithHex("libUE4.so", 0x3DD12B0, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\UE4181\Engine\Source\Runtime\Core\Private\Misc\Paths.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3DDBCD8, "54 65 78 74 72 75 65 50").Modify(); // TextruePath
MemoryPatch::createWithHex("libUE4.so", 0x3DDC844, "49 73 41 75 74 6F 50 61").Modify(); // IsAutoParachutePathPlanningEnable
MemoryPatch::createWithHex("libUE4.so", 0x3DDF7E4, "4D 61 78 50 61 74 68 49").Modify(); // MaxPathIndex
MemoryPatch::createWithHex("libUE4.so", 0x3DE0F94, "62 49 73 50 61 74 68 4D").Modify(); // bIsPathMoveBreking
MemoryPatch::createWithHex("libUE4.so", 0x3DE1FE4, "47 65 74 56 65 68 69 63").Modify(); // GetVehicleIconPath
MemoryPatch::createWithHex("libUE4.so", 0x3DED060, "55 45 6E 75 6D 73 2E 45").Modify(); // UEnums.EAsyncIOPriority = {AIOP_MIN = 0,AIOP_Precache = 0,AIOP_Low = 1,AIOP_BelowNormal = 2,AIOP_Normal = 3,AIOP_High = 4,AIOP_CriticalPath = 5,AIOP_MAX = 5,AIOP_NUM = 6,}
MemoryPatch::createWithHex("libUE4.so", 0x3DEDB58, "63 61 6C 6C 20 46 53 6F").Modify(); // call FSoftObjectPath::IsValid error, argc=%d
MemoryPatch::createWithHex("libUE4.so", 0x3DEDD8C, "54 69 70 73 4A 73 6F 6E").Modify(); // TipsJsonPath
MemoryPatch::createWithHex("libUE4.so", 0x3DF1A54, "43 6C 65 61 72 50 61 6B").Modify(); // ClearPakPathMap
MemoryPatch::createWithHex("libUE4.so", 0x3DFAC5C, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\Addons\Addons\Skills\SkillActions\UAESkillAction_CharMoveByPath.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3DFE4BC, "50 61 74 68 44 61 74 61").Modify(); // PathData
MemoryPatch::createWithHex("libUE4.so", 0x3DFFEE8, "46 75 6E 63 74 69 6F 6E").Modify(); // FunctionFolderPath
MemoryPatch::createWithHex("libUE4.so", 0x3E07E10, "73 6F 66 74 4F 62 6A 50").Modify(); // softObjPath
MemoryPatch::createWithHex("libUE4.so", 0x3E08814, "45 6E 61 62 6C 65 41 75").Modify(); // EnableAutoParachutePathPlanning
MemoryPatch::createWithHex("libUE4.so", 0x3E0D5D0, "54 65 73 74 50 61 74 68").Modify(); // TestPathSyncToLocation
MemoryPatch::createWithHex("libUE4.so", 0x3E16CA8, "54 4C 6F 67 50 61 72 61").Modify(); // TLogParamPath
MemoryPatch::createWithHex("libUE4.so", 0x3E1D434, "4C 6F 67 69 63 41 72 65").Modify(); // LogicAreaFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3E21B30, "43 72 65 61 74 65 57 69").Modify(); // CreateWidgetByPathName
MemoryPatch::createWithHex("libUE4.so", 0x3E292D4, "45 50 61 74 68 45 78 69").Modify(); // EPathExistanceQueryType::NavmeshRaycast2D
MemoryPatch::createWithHex("libUE4.so", 0x3E293E0, "45 50 61 74 68 46 6F 6C").Modify(); // EPathFollowingStatus::Idle
MemoryPatch::createWithHex("libUE4.so", 0x3E2E028, "47 61 6D 65 70 6C 61 79").Modify(); // GameplayCueNotifyPaths
MemoryPatch::createWithHex("libUE4.so", 0x3E38378, "43 6F 70 79 43 6F 6E 74").Modify(); // CopyContentPathToSavePath
MemoryPatch::createWithHex("libUE4.so", 0x3E39824, "50 61 74 68 50 6F 69 6E").Modify(); // PathPointPlayZoneDistances
MemoryPatch::createWithHex("libUE4.so", 0x3E3A1B4, "49 6D 70 6F 72 74 46 69").Modify(); // ImportFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3E3FEC8, "50 61 63 6B 61 67 65 50").Modify(); // PackagePath
MemoryPatch::createWithHex("libUE4.so", 0x3E41B04, "45 4E 61 76 50 61 74 68").Modify(); // ENavPathEvent::MetaPathUpdate
MemoryPatch::createWithHex("libUE4.so", 0x3E46470, "50 69 78 55 49 5F 53 65").Modify(); // PixUI_SetDynamicLibraryPath
MemoryPatch::createWithHex("libUE4.so", 0x3E4648C, "50 69 78 55 49 2D 55 45").Modify(); // PixUI-UE  Error       UPixUIBPLibrary::PixUI_SetDynamicLibraryPath setenv error
MemoryPatch::createWithHex("libUE4.so", 0x3E46A18, "4C 6F 61 64 54 65 78 74").Modify(); // LoadTextureFromFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3E49D68, "43 75 72 72 65 6E 74 4E").Modify(); // CurrentNavPathIndexKey
MemoryPatch::createWithHex("libUE4.so", 0x3E4A910, "43 75 72 76 65 50 61 74").Modify(); // CurvePathMap
MemoryPatch::createWithHex("libUE4.so", 0x3E5106C, "5F 69 6D 67 50 61 74 68").Modify(); // _imgPath
MemoryPatch::createWithHex("libUE4.so", 0x3E5108C, "46 75 6C 6C 50 61 74 68").Modify(); // FullPathName
MemoryPatch::createWithHex("libUE4.so", 0x3E5D6D8, "50 69 78 55 49 2D 55 45").Modify(); // PixUI-UE  Error       LoadImageFromFilePath File not found: %s
MemoryPatch::createWithHex("libUE4.so", 0x3E5E590, "50 61 74 68 43 6F 6E 73").Modify(); // PathConstraintMixTimeline
MemoryPatch::createWithHex("libUE4.so", 0x3E60170, "47 65 74 44 79 6E 61 6D").Modify(); // GetDynamicMeshPath
MemoryPatch::createWithHex("libUE4.so", 0x3E60650, "4C 61 73 74 50 61 74 68").Modify(); // LastPathSegmentTargetSpeed
MemoryPatch::createWithHex("libUE4.so", 0x3E6651C, "41 76 61 74 61 72 50 72").Modify(); // AvatarPropertyLuaFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3E67DE8, "50 6B 67 50 61 74 68 73").Modify(); // PkgPaths_Key
MemoryPatch::createWithHex("libUE4.so", 0x3E6C028, "45 50 61 74 68 46 6F 6C").Modify(); // EPathFollowingAction::DirectMove
MemoryPatch::createWithHex("libUE4.so", 0x3E6D2D4, "47 65 74 52 65 64 69 72").Modify(); // GetRedirectedAssetPathString
MemoryPatch::createWithHex("libUE4.so", 0x3E6E828, "43 61 70 74 75 72 65 50").Modify(); // CapturePath
MemoryPatch::createWithHex("libUE4.so", 0x3E77A30, "49 63 6F 6E 50 61 74 68").Modify(); // IconPath
MemoryPatch::createWithHex("libUE4.so", 0x3E77AB4, "4D 61 72 6B 50 61 74 68").Modify(); // MarkPathSettingArray
MemoryPatch::createWithHex("libUE4.so", 0x3E781A4, "4D 65 73 68 50 61 74 68").Modify(); // MeshPath
MemoryPatch::createWithHex("libUE4.so", 0x3E7BA00, "49 74 65 6D 42 50 43 6C").Modify(); // ItemBPClassPath
MemoryPatch::createWithHex("libUE4.so", 0x3E8097C, "53 75 62 50 61 74 68 53").Modify(); // SubPathString
MemoryPatch::createWithHex("libUE4.so", 0x3E8153C, "69 6D 61 67 65 53 72 63").Modify(); // imageSrcPath
MemoryPatch::createWithHex("libUE4.so", 0x3E818A4, "50 61 74 68 46 6F 6C 6C").Modify(); // PathFollowingComponent
MemoryPatch::createWithHex("libUE4.so", 0x3E8AB74, "48 61 6E 64 6C 65 50 61").Modify(); // HandlePath
MemoryPatch::createWithHex("libUE4.so", 0x3E8C3A0, "4C 6F 61 64 43 6C 61 73").Modify(); // LoadClassFromBPPath
MemoryPatch::createWithHex("libUE4.so", 0x3E8CA64, "47 65 74 57 65 61 70 6F").Modify(); // GetWeaponPlayAnimMontagePath
MemoryPatch::createWithHex("libUE4.so", 0x3E8D098, "50 61 74 68 4D 6F 76 65").Modify(); // PathMoveMaxSpeed
MemoryPatch::createWithHex("libUE4.so", 0x3E8DF88, "49 6E 56 65 68 69 63 6C").Modify(); // InVehicleContainerPath
MemoryPatch::createWithHex("libUE4.so", 0x3E9107C, "50 61 72 61 63 68 75 74").Modify(); // ParachuteMeshPath
MemoryPatch::createWithHex("libUE4.so", 0x3E9868C, "45 4E 61 76 50 61 74 68").Modify(); // ENavPathEvent::UpdatedDueToGoalMoved
MemoryPatch::createWithHex("libUE4.so", 0x3E986CC, "45 4E 61 76 50 61 74 68").Modify(); // ENavPathEvent
MemoryPatch::createWithHex("libUE4.so", 0x3E98B58, "62 44 72 61 77 4C 61 62").Modify(); // bDrawLabelsOnPathNodes
MemoryPatch::createWithHex("libUE4.so", 0x3E9D968, "50 61 6B 50 61 74 68 00").Modify(); // PakPath
MemoryPatch::createWithHex("libUE4.so", 0x3E9D99C, "47 65 74 53 63 72 69 70").Modify(); // GetScriptStructByPath
MemoryPatch::createWithHex("libUE4.so", 0x3E9DF50, "73 74 72 43 61 63 68 65").Modify(); // strCachePathForWrite
MemoryPatch::createWithHex("libUE4.so", 0x3E9E390, "7B 20 22 70 61 74 68 22").Modify(); // { "path":"/storage/emulated/0/vasd/shouyoubao/ManualScreenRecord/com.example.wegame/20211130164636.mp4", "result" : "0", "type" : "video", "size" : "5481842", "rotation" : "0", "width" : "1438", "height" : "720", "uriPath" : "content://media/external/video/media/2107"  }
MemoryPatch::createWithHex("libUE4.so", 0x3E9FFC4, "41 49 4F 63 63 6C 75 73").Modify(); // AIOcclusionFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3EA03EC, "49 6E 41 73 73 65 74 50").Modify(); // InAssetPathList
MemoryPatch::createWithHex("libUE4.so", 0x3EA0CE0, "49 73 4C 61 73 74 50 61").Modify(); // IsLastPathSegmentKey
MemoryPatch::createWithHex("libUE4.so", 0x3EA18A0, "4D 61 74 50 61 74 68 73").Modify(); // MatPaths
MemoryPatch::createWithHex("libUE4.so", 0x3EAED84, "44 65 73 74 72 6F 79 56").Modify(); // DestroyVehicleWithPath
MemoryPatch::createWithHex("libUE4.so", 0x3EB1668, "63 61 6C 6C 20 46 53 6F").Modify(); // call FSoftObjectPath::PostLoadPath error, argc=%d
MemoryPatch::createWithHex("libUE4.so", 0x3EB8F50, "53 6F 66 74 50 61 74 68").Modify(); // SoftPathList
MemoryPatch::createWithHex("libUE4.so", 0x3EB9F90, "43 68 65 63 6B 48 61 76").Modify(); // CheckHaveContentPathFile
MemoryPatch::createWithHex("libUE4.so", 0x3EBA40C, "4F 6E 52 65 70 5F 41 69").Modify(); // OnRep_AirDropPathData
MemoryPatch::createWithHex("libUE4.so", 0x3EBB3D8, "4E 6F 50 61 74 68 54 6F").Modify(); // NoPathToTargetTimer
MemoryPatch::createWithHex("libUE4.so", 0x3EBC0A4, "50 61 74 68 57 61 79 50").Modify(); // PathWayPointNum
MemoryPatch::createWithHex("libUE4.so", 0x3EBCC78, "42 75 6C 6C 65 74 54 65").Modify(); // BulletTemplatePath
MemoryPatch::createWithHex("libUE4.so", 0x3EC8030, "47 65 74 43 75 73 74 6F").Modify(); // GetCustomAssetPathName
MemoryPatch::createWithHex("libUE4.so", 0x3EC8610, "76 69 64 65 6F 50 61 74").Modify(); // videoPath
MemoryPatch::createWithHex("libUE4.so", 0x3EC8D20, "50 69 78 55 49 2D 55 45").Modify(); // PixUI-UE  Log         PxResFont::RegisterFont load success url:%s save Path:%s
MemoryPatch::createWithHex("libUE4.so", 0x3ECCA48, "49 6E 50 61 74 68 00 52").Modify(); // InPath
MemoryPatch::createWithHex("libUE4.so", 0x3ECEC60, "43 61 6C 63 57 61 6C 6B").Modify(); // CalcWalkPathDelta
MemoryPatch::createWithHex("libUE4.so", 0x3ECFFEC, "42 75 69 6C 64 69 6E 67").Modify(); // BuildingSearchPath
MemoryPatch::createWithHex("libUE4.so", 0x3ED6E88, "45 45 6E 76 54 65 73 74").Modify(); // EEnvTestPathfinding
MemoryPatch::createWithHex("libUE4.so", 0x3ED6E9C, "45 45 6E 76 54 65 73 74").Modify(); // EEnvTestPathfinding::Type
MemoryPatch::createWithHex("libUE4.so", 0x3ED8A1C, "62 41 6C 6C 6F 77 4E 61").Modify(); // bAllowNavLinkAsPathEnd
MemoryPatch::createWithHex("libUE4.so", 0x3EDC690, "55 45 6E 75 6D 73 2E 45").Modify(); // UEnums.EShadingPath = {Mobile = 0,Deferred = 1,Num = 2,}
MemoryPatch::createWithHex("libUE4.so", 0x3EDCD40, "63 68 65 63 6B 20 46 53").Modify(); // check FSoftClassPath nil value
MemoryPatch::createWithHex("libUE4.so", 0x3EDD888, "47 65 74 50 72 65 42 75").Modify(); // GetPreBuildingEffectPath
MemoryPatch::createWithHex("libUE4.so", 0x3EDDBF0, "50 69 78 55 49 5F 53 65").Modify(); // PixUI_SetMatBasePath
MemoryPatch::createWithHex("libUE4.so", 0x3EDFDC4, "52 73 70 50 61 74 68 50").Modify(); // RspPathPoints
MemoryPatch::createWithHex("libUE4.so", 0x3EE1828, "4D 69 64 43 75 72 76 65").Modify(); // MidCurvePath
MemoryPatch::createWithHex("libUE4.so", 0x3EE7CE8, "62 4C 6F 61 64 50 61 74").Modify(); // bLoadPathCompressionCfgWhenReadTable
MemoryPatch::createWithHex("libUE4.so", 0x3EE7E28, "43 6F 6E 76 65 72 74 54").Modify(); // ConvertToAbsolutePathForExternalAppForRead
MemoryPatch::createWithHex("libUE4.so", 0x3EEDDEC, "50 61 74 68 4C 65 6E 67").Modify(); // PathLength
MemoryPatch::createWithHex("libUE4.so", 0x3EF0BD8, "53 75 70 70 72 65 73 73").Modify(); // SuppressWwiseProjectPathWarnings
MemoryPatch::createWithHex("libUE4.so", 0x3EFCD4C, "47 65 74 41 63 63 65 73").Modify(); // GetAccessoryAvatarHandlePath
MemoryPatch::createWithHex("libUE4.so", 0x3EFDE98, "46 69 6C 65 53 61 76 65").Modify(); // FileSavePath
MemoryPatch::createWithHex("libUE4.so", 0x3EFF5AC, "62 4E 6F 50 61 72 74 69").Modify(); // bNoPartialPath
MemoryPatch::createWithHex("libUE4.so", 0x3F0809C, "47 65 74 4C 75 61 46 69").Modify(); // GetLuaFilePath
MemoryPatch::createWithHex("libUE4.so", 0x3F28D10, "53 6F 75 6E 64 62 61 6E").Modify(); // Soundbanks have been generated with convolution reverb parameters that do not match sound engine runtime conditions. No wet path will be heard.
MemoryPatch::createWithHex("libUE4.so", 0x3F3AEA0, "52 65 63 6F 72 64 65 72").Modify(); // Recorder: Cannot create output file; was a writable path provided via <IOHookClass>::AddBasePath()?
MemoryPatch::createWithHex("libUE4.so", 0x4016B18, "70 61 74 68 00 00 00 00").Modify(); // path
MemoryPatch::createWithHex("libUE4.so", 0x4016B38, "63 70 61 74 68 00 00 00").Modify(); // cpath
MemoryPatch::createWithHex("libUE4.so", 0x4016C00, "4C 55 41 5F 50 41 54 48").Modify(); // LUA_PATH
MemoryPatch::createWithHex("libUE4.so", 0x4016CA8, "4C 55 41 5F 43 50 41 54").Modify(); // LUA_CPATH
MemoryPatch::createWithHex("libUE4.so", 0x4016D30, "73 65 61 72 63 68 70 61").Modify(); // searchpath
MemoryPatch::createWithHex("libUE4.so", 0x404EF5C, "2D 2D 20 50 72 6F 74 65").Modify(); // -- Protects a path segment, to prevent it from interfering with the
MemoryPatch::createWithHex("libUE4.so", 0x404F4EC, "2D 2D 20 20 20 62 61 73").Modify(); // --   base_path
MemoryPatch::createWithHex("libUE4.so", 0x404F588, "6C 6F 63 61 6C 20 66 75").Modify(); // local function absolute_path(base_path, relative_path)
MemoryPatch::createWithHex("libUE4.so", 0x4050E68, "2D 2D 20 42 72 65 61 6B").Modify(); // -- Breaks a path into its segments, unescaping the segments
MemoryPatch::createWithHex("libUE4.so", 0x4050F74, "20 20 20 20 70 61 74 68").Modify(); //     path = path or ""
MemoryPatch::createWithHex("libUE4.so", 0x4051090, "20 20 20 20 69 66 20 73").Modify(); //     if string.sub(path, -1, -1) == "/" then parsed.is_directory = 1 end
MemoryPatch::createWithHex("libUE4.so", 0x405129C, "20 20 20 20 6C 6F 63 61").Modify(); //     local path = ""
MemoryPatch::createWithHex("libUE4.so", 0x40514EC, "20 20 20 20 69 66 20 70").Modify(); //     if parsed.is_absolute then path = "/" .. path end

// ========== traceback ==========
MemoryPatch::createWithHex("libUE4.so", 0x3F477D8, "73 74 61 63 6B 20 74 72").Modify(); // stack traceback:
MemoryPatch::createWithHex("libUE4.so", 0x4018368, "74 72 61 63 65 62 61 63").Modify(); // traceback

// ========== aLog ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCC72C, "5F 5A 4E 35 41 42 61 73").Modify(); // _ZN5ABase4XLogEN6GCloud12ALogPriorityEPKcjS3_S3_z
MemoryPatch::createWithHex("libUE4.so", 0x3C56DD8, "4F 70 65 6E 4F 72 43 6C").Modify(); // OpenOrCloseLuaLog
MemoryPatch::createWithHex("libUE4.so", 0x3C9F9F0, "4F 6E 52 65 6D 6F 76 65").Modify(); // OnRemoveLuaLogicManagerEvent
MemoryPatch::createWithHex("libUE4.so", 0x3CBC5AC, "41 6E 64 72 6F 69 64 54").Modify(); // AndroidThunkJava_HideVirtualKeyboardInputDialog
MemoryPatch::createWithHex("libUE4.so", 0x3D39970, "62 41 6E 61 6C 6F 67 4D").Modify(); // bAnalogMode
MemoryPatch::createWithHex("libUE4.so", 0x3D68420, "4F 6E 52 65 6D 6F 76 65").Modify(); // OnRemoveLuaLogicManagerEvent__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3D8AC68, "4D 69 6E 41 6E 61 6C 6F").Modify(); // MinAnalogWalkSpeed
MemoryPatch::createWithHex("libUE4.so", 0x3DBCCFC, "49 6E 41 6E 61 6C 6F 67").Modify(); // InAnalogInputEvent
MemoryPatch::createWithHex("libUE4.so", 0x3E06528, "41 6E 64 72 6F 69 64 54").Modify(); // AndroidThunkJava_ShowHiddenAlertDialog
MemoryPatch::createWithHex("libUE4.so", 0x3E2A50C, "62 54 72 65 61 74 41 73").Modify(); // bTreatAsDialogue
MemoryPatch::createWithHex("libUE4.so", 0x3F2D5F8, "41 6E 61 6C 6F 67 49 6E").Modify(); // AnalogInput
MemoryPatch::createWithHex("libUE4.so", 0x3F3FD30, "6D 43 6F 6E 74 72 6F 6C").Modify(); // mControlAnalogVals
MemoryPatch::createWithHex("libUE4.so", 0x3F8E2E4, "54 61 67 61 6C 6F 67 00").Modify(); // Tagalog
MemoryPatch::createWithHex("libUE4.so", 0x3F8E2EC, "54 61 67 61 6C 6F 67 00").Modify(); // Tagalog

// ========== AnoSDKIoctlOld ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCB2A0, "41 6E 6F 53 44 4B 49 6F").Modify(); // AnoSDKIoctlOld

// ========== AnoSDKOnRecvData ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCBA30, "41 6E 6F 53 44 4B 4F 6E").Modify(); // AnoSDKOnRecvData

// ========== AnoSDKIoctl ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCB2A0, "41 6E 6F 53 44 4B 49 6F").Modify(); // AnoSDKIoctlOld

// ========== REPORT ==========
MemoryPatch::createWithHex("libUE4.so", 0x2DCE984, "5F 5A 4E 36 47 43 6C 6F").Modify(); // _ZN6GCloud10CrashSight21CrashSightMobileAgent19ConfigCrashReporterEi
MemoryPatch::createWithHex("libUE4.so", 0x3C576BC, "47 65 74 42 75 67 52 65").Modify(); // GetBugReporter
MemoryPatch::createWithHex("libUE4.so", 0x3C5828C, "45 52 65 61 6C 74 69 6D").Modify(); // ERealtimeReportType
MemoryPatch::createWithHex("libUE4.so", 0x3C5ECAC, "47 4D 53 65 6E 64 44 61").Modify(); // GMSendDailyTaskReport
MemoryPatch::createWithHex("libUE4.so", 0x3C6A70C, "62 45 6E 61 62 6C 65 44").Modify(); // bEnableDSErrorLogReport
MemoryPatch::createWithHex("libUE4.so", 0x3C6DA24, "41 6C 6C 53 74 61 72 52").Modify(); // AllStarReportData
MemoryPatch::createWithHex("libUE4.so", 0x3C701F0, "50 6C 65 61 73 65 20 72").Modify(); // Please report it to me at: jseward@bzip.org.  If this happened
MemoryPatch::createWithHex("libUE4.so", 0x3C7DB48, "53 65 74 74 69 6E 67 52").Modify(); // SettingReportItem_IntIntMap
MemoryPatch::createWithHex("libUE4.so", 0x3C81760, "53 65 72 76 65 72 52 65").Modify(); // ServerReportProtection
MemoryPatch::createWithHex("libUE4.so", 0x3C8184C, "4F 6E 43 6C 69 65 6E 74").Modify(); // OnClientReportPeerVisualFieldActorList
MemoryPatch::createWithHex("libUE4.so", 0x3C91988, "52 65 70 6F 72 74 49 6E").Modify(); // ReportInterval
MemoryPatch::createWithHex("libUE4.so", 0x3C98850, "54 50 65 72 66 6F 72 50").Modify(); // TPerforPlatDataReport
MemoryPatch::createWithHex("libUE4.so", 0x3C98AE8, "4F 6E 55 49 53 74 61 74").Modify(); // OnUIStatReport__DelegateSignature
MemoryPatch::createWithHex("libUE4.so", 0x3C998A8, "48 61 73 56 65 68 69 63").Modify(); // HasVehicleReportEntry
MemoryPatch::createWithHex("libUE4.so", 0x3CAE698, "4F 62 6A 20 72 65 70 6F").Modify(); // Obj report mark
MemoryPatch::createWithHex("libUE4.so", 0x3CAE910, "47 65 74 50 6C 61 79 65").Modify(); // GetPlayerStatusReportInfo
MemoryPatch::createWithHex("libUE4.so", 0x3CAEE84, "52 65 70 6F 72 74 53 63").Modify(); // ReportScore
MemoryPatch::createWithHex("libUE4.so", 0x3CDA48C, "52 65 70 6F 72 74 43 72").Modify(); // ReportCrashLogWithFDNum
MemoryPatch::createWithHex("libUE4.so", 0x3CEE580, "62 55 73 65 41 6E 74 69").Modify(); // bUseAntiDataReportFilterCheck
MemoryPatch::createWithHex("libUE4.so", 0x3CF1E14, "47 65 74 4D 61 78 57 65").Modify(); // GetMaxWeaponReportNum
MemoryPatch::createWithHex("libUE4.so", 0x3D00DA0, "4C 61 73 74 54 69 6D 65").Modify(); // LastTimeReportEuipmentFlow
MemoryPatch::createWithHex("libUE4.so", 0x3D0809C, "4E 65 74 77 6F 72 6B 52").Modify(); // NetworkReportActor
MemoryPatch::createWithHex("libUE4.so", 0x3D08130, "52 65 70 6F 72 74 54 61").Modify(); // ReportTaskExtInfo
MemoryPatch::createWithHex("libUE4.so", 0x3D19868, "45 6E 61 62 6C 65 52 65").Modify(); // EnableReportGameSettingLevel
MemoryPatch::createWithHex("libUE4.so", 0x3D1CFCC, "50 65 72 66 52 65 70 6F").Modify(); // PerfReportSetLabel
MemoryPatch::createWithHex("libUE4.so", 0x3D2BD10, "43 68 65 63 6B 4E 65 65").Modify(); // CheckNeedReportChatMsgInfo
MemoryPatch::createWithHex("libUE4.so", 0x3D30CD8, "62 46 6F 72 63 65 52 65").Modify(); // bForceReportException
MemoryPatch::createWithHex("libUE4.so", 0x3D46B44, "53 74 61 74 65 52 65 70").Modify(); // StateReportData
MemoryPatch::createWithHex("libUE4.so", 0x3D46C50, "52 65 70 6F 72 74 41 69").Modify(); // ReportAimFlow
MemoryPatch::createWithHex("libUE4.so", 0x3D48EE8, "52 65 70 6F 72 74 54 79").Modify(); // ReportType
MemoryPatch::createWithHex("libUE4.so", 0x3D57F7C, "52 65 70 6F 72 74 50 72").Modify(); // ReportPriority
MemoryPatch::createWithHex("libUE4.so", 0x3D5A668, "52 50 43 5F 52 65 70 6C").Modify(); // RPC_Replay_RefreshSettingReportData
MemoryPatch::createWithHex("libUE4.so", 0x3D5C9C0, "43 68 65 63 6B 4E 65 65").Modify(); // CheckNeedReportSignMsgInfo
MemoryPatch::createWithHex("libUE4.so", 0x3D5D2E8, "53 65 76 65 72 52 65 70").Modify(); // SeverReportSimulateDrag
MemoryPatch::createWithHex("libUE4.so", 0x3D77BD0, "52 65 70 6F 72 74 46 69").Modify(); // ReportFileForAbroad
MemoryPatch::createWithHex("libUE4.so", 0x3D8B344, "62 53 68 6F 75 6C 64 52").Modify(); // bShouldReportAntiCheat
MemoryPatch::createWithHex("libUE4.so", 0x3D8B48C, "54 65 61 6D 6D 61 74 65").Modify(); // TeammateDisappearReportDistance
MemoryPatch::createWithHex("libUE4.so", 0x3D8EA7C, "52 65 70 6F 72 74 54 61").Modify(); // ReportTaskData
MemoryPatch::createWithHex("libUE4.so", 0x3DA10AC, "62 52 65 70 6F 72 74 00").Modify(); // bReport
MemoryPatch::createWithHex("libUE4.so", 0x3DB1514, "53 65 74 47 61 6D 65 45").Modify(); // SetGameEndReportData
MemoryPatch::createWithHex("libUE4.so", 0x3DB7B9C, "53 65 72 76 65 72 52 65").Modify(); // ServerReportExceptionData
MemoryPatch::createWithHex("libUE4.so", 0x3DB8B5C, "47 61 6D 65 42 75 67 52").Modify(); // GameBugReporter
MemoryPatch::createWithHex("libUE4.so", 0x3DBED14, "45 52 65 70 6F 72 74 65").Modify(); // EReporterLineStyle::Type
MemoryPatch::createWithHex("libUE4.so", 0x3DCDBC0, "44 3A 5C 52 65 6C 65 61").Modify(); // D:\Release4.3.0\AS\Survive\Source\Client\Tools\BugReporter.cpp
MemoryPatch::createWithHex("libUE4.so", 0x3DCE980, "45 52 65 61 6C 74 69 6D").Modify(); // ERealtimeReportType::CharMove1
MemoryPatch::createWithHex("libUE4.so", 0x3DE15A8, "4F 6E 43 6C 69 65 6E 74").Modify(); // OnClientReportPeerVisualFieldAcotrList
MemoryPatch::createWithHex("libUE4.so", 0x3DF9610, "4F 6E 52 65 66 72 65 73").Modify(); // OnRefreshReportSettingConfig
MemoryPatch::createWithHex("libUE4.so", 0x3E08998, "53 65 74 52 65 70 6F 72").Modify(); // SetReportChatMsgInfo
MemoryPatch::createWithHex("libUE4.so", 0x3E0C1CC, "49 73 45 6E 61 62 6C 65").Modify(); // IsEnableReportMrpcsInCircleFlow
MemoryPatch::createWithHex("libUE4.so", 0x3E1E508, "52 50 43 5F 53 65 72 76").Modify(); // RPC_Server_ReportFloatArrayUnreliable
MemoryPatch::createWithHex("libUE4.so", 0x3E1EE40, "4F 6E 52 65 70 6F 72 74").Modify(); // OnReportPlayerEquipmentFlow
MemoryPatch::createWithHex("libUE4.so", 0x3E3B77C, "52 65 70 6F 72 74 46 69").Modify(); // ReportFirebaseEventWithString
MemoryPatch::createWithHex("libUE4.so", 0x3E3BBD4, "56 6F 69 63 65 53 64 6B").Modify(); // VoiceSdkQuitLbsRoomReportEnable
MemoryPatch::createWithHex("libUE4.so", 0x3E47200, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportEvent(std::string eventName, bool isRealTime) end
MemoryPatch::createWithHex("libUE4.so", 0x3E60AB0, "52 65 70 6F 72 74 49 6E").Modify(); // ReportIntArrayData
MemoryPatch::createWithHex("libUE4.so", 0x3E67E04, "4F 6E 52 65 70 6F 72 74").Modify(); // OnReportSettingConfigStart
MemoryPatch::createWithHex("libUE4.so", 0x3E685C8, "56 65 68 69 63 6C 65 50").Modify(); // VehicleProtectionReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E68614, "56 65 68 69 63 6C 65 52").Modify(); // VehicleReportEntry
MemoryPatch::createWithHex("libUE4.so", 0x3E6B05C, "45 72 72 6F 72 52 65 70").Modify(); // ErrorReporting.EmptyBox
MemoryPatch::createWithHex("libUE4.so", 0x3E6B074, "45 72 72 6F 72 52 65 70").Modify(); // ErrorReporting.BackgroundColor
MemoryPatch::createWithHex("libUE4.so", 0x3E78A60, "43 68 61 72 61 63 74 65").Modify(); // CharacterStateReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E7C3D0, "52 65 70 6F 72 74 4F 70").Modify(); // ReportOpPanelExceptionData
MemoryPatch::createWithHex("libUE4.so", 0x3E88CC8, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportPurchase(std::string purchaseName,std::string currencyCode, std::string expense, bool isRealTime) start
MemoryPatch::createWithHex("libUE4.so", 0x3E8B658, "47 65 74 43 68 61 72 61").Modify(); // GetCharacterStateReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E8B674, "52 65 70 6F 72 74 44 61").Modify(); // ReportData
MemoryPatch::createWithHex("libUE4.so", 0x3E9E5C0, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportEvent(std::string eventName,std::vector<KVPair> cEventList, bool isRealTime) start
MemoryPatch::createWithHex("libUE4.so", 0x3E9E62C, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportPurchase(std::string purchaseName,std::string currencyCode, std::string expense, bool isRealTime) end
MemoryPatch::createWithHex("libUE4.so", 0x3EA72B8, "53 65 74 43 72 61 73 68").Modify(); // SetCrashContextReportLevel
MemoryPatch::createWithHex("libUE4.so", 0x3EB78A0, "53 65 74 54 65 73 74 54").Modify(); // SetTestTaskReportData
MemoryPatch::createWithHex("libUE4.so", 0x3EC9478, "49 4D 53 44 4B 53 74 61").Modify(); // IMSDKStatManager::reportRevenue(std::string eventToken, std::string currency, std::string value, std::map<std::string, std::string> params, std::string extraJson ) end
MemoryPatch::createWithHex("libUE4.so", 0x3EE64F0, "52 65 70 6F 72 74 54 65").Modify(); // ReportTeammateClientLocationError
MemoryPatch::createWithHex("libUE4.so", 0x3EFDCC8, "45 6E 61 62 6C 65 52 65").Modify(); // EnableReportVoiceSdkEvent
MemoryPatch::createWithHex("libUE4.so", 0x3F093E8, "4F 6E 52 65 70 6F 72 74").Modify(); // OnReportData
MemoryPatch::createWithHex("libUE4.so", 0x3F27A10, "63 6F 6E 74 61 63 74 52").Modify(); // contactReportThreshold
MemoryPatch::createWithHex("libUE4.so", 0x3F2AFA8, "49 3A 5C 64 65 76 5F 65").Modify(); // I:\dev_engine\DevOps\UE4181\Engine\Source\ThirdParty\PhysX\PhysX_3.4\Source\SimulationController\src\ScContactReportBuffer.h
MemoryPatch::createWithHex("libUE4.so", 0x3F2BF98, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_SCENE_QUERY
MemoryPatch::createWithHex("libUE4.so", 0x3F2F410, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_TRIGGER_NOTIFY
MemoryPatch::createWithHex("libUE4.so", 0x3F31AE0, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_CONSTRAINT_BREAK_NOTIFY
MemoryPatch::createWithHex("libUE4.so", 0x3F370D0, "43 6F 6E 74 61 63 74 52").Modify(); // ContactReportThreshold
MemoryPatch::createWithHex("libUE4.so", 0x3F3C078, "65 52 45 50 4F 52 54 5F").Modify(); // eREPORT_TO_FOREIGN_CLIENTS_CONTACT_NOTIFY
MemoryPatch::createWithHex("libUE4.so", 0x3F3E940, "53 63 53 63 65 6E 65 2E").Modify(); // ScScene.lostTouchReports
MemoryPatch::createWithHex("libUE4.so", 0x3F4B400, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairReport]
MemoryPatch::createWithHex("libUE4.so", 0x3F4B550, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairContactReportData]
MemoryPatch::createWithHex("libUE4.so", 0x3F4B6B0, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairReport*]
MemoryPatch::createWithHex("libUE4.so", 0x3F4EC80, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Bp::BroadPhasePairReport]
MemoryPatch::createWithHex("libUE4.so", 0x3F4F710, "73 74 61 74 69 63 20 63").Modify(); // static const char* physx::shdfnd::ReflectionAllocator<T>::getName() [with T = physx::Sc::ActorPairReport*]
