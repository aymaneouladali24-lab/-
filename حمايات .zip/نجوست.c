// 4A Protection Tool - Extracted Offsets
// Library: libanogs.so
// Date: 2026-03-26 15:59:18.176570
// Total keywords: 89


// ========== Monitor ==========
MemoryPatch::createWithHex("libanogs.so", 0x9F734, "6D 6F 6E 69 74 6F 72 00").Modify(); // monitor

// ========== CoreReport ==========
MemoryPatch::createWithHex("libanogs.so", 0xA2DA8, "43 4F 52 45 52 45 50 4F").Modify(); // COREREPORT

// ========== Tss ==========
MemoryPatch::createWithHex("libanogs.so", 0xA0A70, "69 6E 69 74 5F 69 6E 66").Modify(); // init_info->tss_sdk_send_data_to_svr:%p
MemoryPatch::createWithHex("libanogs.so", 0x52AE00, "54 53 53 5F 53 44 4B 5F").Modify(); // TSS_SDK_SIGDATA

// ========== Report ==========
MemoryPatch::createWithHex("libanogs.so", 0x2554, "41 6E 6F 53 44 4B 44 65").Modify(); // AnoSDKDelReportData3
MemoryPatch::createWithHex("libanogs.so", 0xA0E00, "68 65 6C 6C 6F 20 67 65").Modify(); // hello getreportdata3
MemoryPatch::createWithHex("libanogs.so", 0xA2DA8, "43 4F 52 45 52 45 50 4F").Modify(); // COREREPORT

// ========== Path ==========
MemoryPatch::createWithHex("libanogs.so", 0xA05EC, "70 61 74 68 3D 25 73 00").Modify(); // path=%s

// ========== check_state ==========
MemoryPatch::createWithHex("libanogs.so", 0xA1BD4, "63 68 65 63 6B 5F 73 74").Modify(); // check_state=%s

// ========== AnoSDKDelReportData3 ==========
MemoryPatch::createWithHex("libanogs.so", 0x2554, "41 6E 6F 53 44 4B 44 65").Modify(); // AnoSDKDelReportData3

// ========== AnoSDKIoctlOld ==========
MemoryPatch::createWithHex("libanogs.so", 0x2504, "41 6E 6F 53 44 4B 49 6F").Modify(); // AnoSDKIoctlOld

// ========== AnoSDKOnResume ==========
MemoryPatch::createWithHex("libanogs.so", 0x24BC, "41 6E 6F 53 44 4B 4F 6E").Modify(); // AnoSDKOnResume

// ========== AnoSDKIoctl ==========
MemoryPatch::createWithHex("libanogs.so", 0x2504, "41 6E 6F 53 44 4B 49 6F").Modify(); // AnoSDKIoctlOld

// ========== AnoSDKDelReportData ==========
MemoryPatch::createWithHex("libanogs.so", 0x2554, "41 6E 6F 53 44 4B 44 65").Modify(); // AnoSDKDelReportData3

// ========== COREREPORT ==========
MemoryPatch::createWithHex("libanogs.so", 0xA2DA8, "43 4F 52 45 52 45 50 4F").Modify(); // COREREPORT

// ========== REPORT ==========
MemoryPatch::createWithHex("libanogs.so", 0x2554, "41 6E 6F 53 44 4B 44 65").Modify(); // AnoSDKDelReportData3
MemoryPatch::createWithHex("libanogs.so", 0xA0E00, "68 65 6C 6C 6F 20 67 65").Modify(); // hello getreportdata3
MemoryPatch::createWithHex("libanogs.so", 0xA2DA8, "43 4F 52 45 52 45 50 4F").Modify(); // COREREPORT

// ========== check_state ==========
MemoryPatch::createWithHex("libanogs.so", 0xA1BD4, "63 68 65 63 6B 5F 73 74").Modify(); // check_state=%s
