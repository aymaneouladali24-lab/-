// 4A Protection Tool - Extracted Offsets
// Library: libTDataMaster.so
// Date: 2026-03-26 16:31:55.715189
// Total keywords: 89


// ========== TdmReport ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD3D8, "4A 4E 49 20 54 44 4D 52").Modify(); // JNI TDMReportBinary, data is null!

// ========== Report ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x26F0, "4A 61 76 61 5F 63 6F 6D").Modify(); // Java_com_tdatamaster_tdm_TDataMaster_TDMEnableReport
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DC8, "74 64 6D 5F 72 65 70 6F").Modify(); // tdm_report_login
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E6C, "54 44 4D 5F 52 65 70 6F").Modify(); // TDM_Report_Binary
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E90, "5F 5A 4E 36 47 43 6C 6F").Modify(); // _ZN6GCloud6Plugin12PluginReport10OnShutdownEv
MemoryPatch::createWithHex("libTDataMaster.so", 0x2F20, "5F 5A 4E 36 47 43 6C 6F").Modify(); // _ZN6GCloud6Plugin12PluginReport16GetServiceByNameEPKc
MemoryPatch::createWithHex("libTDataMaster.so", 0x3010, "5F 5A 4E 4B 36 47 43 6C").Modify(); // _ZNK6GCloud6Plugin12PluginReport7GetNameEv
MemoryPatch::createWithHex("libTDataMaster.so", 0x30B4, "5F 5A 54 68 6E 38 5F 4E").Modify(); // _ZThn8_N6GCloud6Plugin12PluginReport13OnPostStartupEv
MemoryPatch::createWithHex("libTDataMaster.so", 0x3120, "5F 5A 54 68 6E 38 5F 4E").Modify(); // _ZThn8_N6GCloud6Plugin12PluginReport16GetServiceByNameEPKc
MemoryPatch::createWithHex("libTDataMaster.so", 0x31CC, "5F 5A 54 68 6E 38 5F 4E").Modify(); // _ZThn8_N6GCloud6Plugin12PluginReportD1Ev
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D787C, "52 65 70 6F 72 74 20 6D").Modify(); // Report mode : %d
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7A0C, "52 65 70 6F 72 74 53 74").Modify(); // ReportStartup
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7D20, "52 65 70 6F 72 74 20 6C").Modify(); // Report login user event, platform:%d, openid:%s
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7E70, "4E 33 54 44 4D 31 33 45").Modify(); // N3TDM13EventReporterE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7EB0, "4E 33 54 44 4D 31 34 49").Modify(); // N3TDM14IEventReporterE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D85B4, "68 74 74 70 20 72 65 70").Modify(); // http report is not enable
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D861C, "69 73 5F 63 6F 6D 70 72").Modify(); // is_compress_report
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D86D0, "72 65 70 6F 72 74 5F 69").Modify(); // report_interval
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D8BF8, "6E 6F 74 68 69 6E 67 20").Modify(); // nothing to report
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9244, "47 65 74 46 69 6C 65 4E").Modify(); // GetFileNameForReport
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9304, "2F 55 73 65 72 73 2F 69").Modify(); // /Users/intl/devops/PUBGM/TDMWorkspace/tdm/Project/TDM/Source/TDataMasterReporter.cpp
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9448, "72 65 70 6F 72 74 2D 62").Modify(); // report-bin
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9504, "72 65 70 6F 72 74 20 73").Modify(); // report success--------------------------------------
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D95D4, "2F 55 73 65 72 73 2F 69").Modify(); // /Users/intl/devops/PUBGM/TDMWorkspace/tdm/Project/TDM/Source/TDataMasterReportManager.cpp
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9840, "4F 6E 48 54 54 50 52 65").Modify(); // OnHTTPReportResp
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D98C8, "48 54 54 50 20 72 65 70").Modify(); // HTTP report error, error code : %d, error msg : %s
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9924, "48 54 54 50 20 72 65 70").Modify(); // HTTP report success
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9938, "68 74 74 70 20 72 65 70").Modify(); // http report success but delete file error
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9D28, "63 6F 6D 2F 74 64 61 74").Modify(); // com/tdatamaster/tdm/gcloud/service/PluginReportService
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DAE74, "5B 54 44 4D 20 48 54 54").Modify(); // [TDM HTTP] httpclient Create Request Thread Report Type is none
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD1D4, "4A 4E 49 20 54 44 4D 45").Modify(); // JNI TDMEnableReport %s
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD3D8, "4A 4E 49 20 54 44 4D 52").Modify(); // JNI TDMReportBinary, data is null!
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD8EC, "74 64 6D 5F 65 6E 61 62").Modify(); // tdm_enable_report
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD9AC, "74 64 6D 5F 72 65 70 6F").Modify(); // tdm_report_event, data is null.
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDC00, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin12PluginReportE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDC20, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin9SingletonINS0_12PluginReportEEE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDD48, "52 65 70 6F 72 74 53 65").Modify(); // ReportService::GetSessionID
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDD64, "52 65 70 6F 72 74 53 65").Modify(); // ReportService::GetTDMUID
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDFF0, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin13ReportServiceE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DE030, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin14IReportServiceE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DF9D0, "4E 33 54 44 4D 31 39 54").Modify(); // N3TDM19TDMDeviceReportTaskE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E3E78, "43 61 6E 27 74 20 63 6F").Modify(); // Can't complete SOCKS4 connection to %d.%d.%d.%d:%d. (%d), request rejected because the client program and identd report different user-ids.
MemoryPatch::createWithHex("libTDataMaster.so", 0x324EC0, "6E 6F 74 20 65 6E 6F 75").Modify(); // not enough space for format expansion (Please submit full bug report at http://gcc.gnu.org/bugs.html):

// ========== Server ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E1748, "45 6D 70 74 79 20 72 65").Modify(); // Empty reply from server
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E1EB0, "53 65 72 76 65 72 3A 00").Modify(); // Server:
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E3298, "48 54 54 50 20 73 65 72").Modify(); // HTTP server doesn't seem to support byte ranges. Cannot resume.
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E3DF0, "43 61 6E 27 74 20 63 6F").Modify(); // Can't complete SOCKS4 connection to %d.%d.%d.%d:%d. (%d), request rejected because SOCKS server cannot connect to identd on the client.
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E4118, "55 73 65 72 20 77 61 73").Modify(); // User was rejected by the SOCKS5 server (%d %d).
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E4188, "4E 6F 20 61 75 74 68 65").Modify(); // No authentication method was acceptable. (It is quite likely that the SOCKS5 server wanted a username/password, since none was supplied to the server on this connection.)
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E4268, "55 6E 64 6F 63 75 6D 65").Modify(); // Undocumented SOCKS5 mode attempted to be used by server.
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E5578, "53 65 72 76 65 72 20 68").Modify(); // Server hello
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E5588, "53 65 72 76 65 72 20 76").Modify(); // Server verify
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E5598, "53 65 72 76 65 72 20 66").Modify(); // Server finished
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E5600, "53 65 72 76 65 72 20 6B").Modify(); // Server key exchange
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E8038, "73 73 6C 5F 73 65 72 76").Modify(); // ssl_server
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E8F98, "53 45 52 56 45 52 49 4E").Modify(); // SERVERINFO FOR
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E9110, "73 65 72 76 65 72 20 66").Modify(); // server finished
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E9328, "21 65 78 70 65 63 74 65").Modify(); // !expected_len || s->s3->previous_server_finished_len
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E96D0, "73 65 72 76 65 72 20 66").Modify(); // server finished
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA000, "64 74 6C 73 31 5F 73 65").Modify(); // dtls1_send_server_certificate
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA020, "64 74 6C 73 31 5F 73 65").Modify(); // dtls1_send_server_hello
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA038, "64 74 6C 73 31 5F 73 65").Modify(); // dtls1_send_server_key_exchange
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA0C0, "47 45 54 5F 53 45 52 56").Modify(); // GET_SERVER_FINISHED
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA0D8, "47 45 54 5F 53 45 52 56").Modify(); // GET_SERVER_HELLO
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA0F0, "47 45 54 5F 53 45 52 56").Modify(); // GET_SERVER_STATIC_DH_KEY
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA110, "47 45 54 5F 53 45 52 56").Modify(); // GET_SERVER_VERIFY
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA158, "53 45 52 56 45 52 5F 46").Modify(); // SERVER_FINISH
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA168, "53 45 52 56 45 52 5F 48").Modify(); // SERVER_HELLO
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA178, "53 45 52 56 45 52 5F 56").Modify(); // SERVER_VERIFY
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA1D8, "53 53 4C 32 33 5F 47 45").Modify(); // SSL23_GET_SERVER_HELLO
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA588, "73 73 6C 33 5F 67 65 74").Modify(); // ssl3_get_server_certificate
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA5A8, "73 73 6C 33 5F 67 65 74").Modify(); // ssl3_get_server_done
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA5C0, "73 73 6C 33 5F 67 65 74").Modify(); // ssl3_get_server_hello
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA6C8, "73 73 6C 33 5F 73 65 6E").Modify(); // ssl3_send_server_certificate
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA6E8, "73 73 6C 33 5F 73 65 6E").Modify(); // ssl3_send_server_hello
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA700, "73 73 6C 33 5F 73 65 6E").Modify(); // ssl3_send_server_key_exchange
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA888, "73 73 6C 5F 61 64 64 5F").Modify(); // ssl_add_serverhello_renegotiate_ext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA8B0, "73 73 6C 5F 61 64 64 5F").Modify(); // ssl_add_serverhello_tlsext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA8D0, "73 73 6C 5F 61 64 64 5F").Modify(); // ssl_add_serverhello_use_srtp_ext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EA9A0, "53 53 4C 5F 43 48 45 43").Modify(); // SSL_CHECK_SERVERHELLO_TLSEXT
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EACC8, "53 53 4C 5F 43 54 58 5F").Modify(); // SSL_CTX_use_serverinfo
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EACE0, "53 53 4C 5F 43 54 58 5F").Modify(); // SSL_CTX_use_serverinfo_file
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAD48, "53 53 4C 5F 47 45 54 5F").Modify(); // SSL_GET_SERVER_CERT_INDEX
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAD68, "53 53 4C 5F 47 45 54 5F").Modify(); // SSL_GET_SERVER_SEND_CERT
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAD88, "73 73 6C 5F 67 65 74 5F").Modify(); // ssl_get_server_send_pkey
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAE68, "73 73 6C 5F 70 61 72 73").Modify(); // ssl_parse_serverhello_renegotiate_ext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAE90, "73 73 6C 5F 70 61 72 73").Modify(); // ssl_parse_serverhello_tlsext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAEB0, "73 73 6C 5F 70 61 72 73").Modify(); // ssl_parse_serverhello_use_srtp_ext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAF08, "73 73 6C 5F 70 72 65 70").Modify(); // ssl_prepare_serverhello_tlsext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EAF88, "53 53 4C 5F 53 43 41 4E").Modify(); // SSL_SCAN_SERVERHELLO_TLSEXT
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EB300, "54 4C 53 31 5F 43 48 45").Modify(); // TLS1_CHECK_SERVERHELLO_TLSEXT
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EB398, "54 4C 53 31 5F 50 52 45").Modify(); // TLS1_PREPARE_SERVERHELLO_TLSEXT
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EB3E0, "74 6C 73 31 5F 73 65 74").Modify(); // tls1_set_server_sigalgs
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EBE70, "69 6E 76 61 6C 69 64 20").Modify(); // invalid serverinfo data
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EBF88, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server bad ticket
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EBFA0, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server init
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EBFB8, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server rd_req (keytab perms?)
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EBFE0, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server tkt expired
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EBFF8, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server tkt not yet valid
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EC018, "6B 72 62 35 20 73 65 72").Modify(); // krb5 server tkt skew
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EC1C8, "63 61 6E 27 74 20 66 69").Modify(); // can't find SRP server param
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EC7F8, "70 73 6B 20 6E 6F 20 73").Modify(); // psk no server cb
MemoryPatch::createWithHex("libTDataMaster.so", 0x2ECA10, "73 65 72 76 65 72 68 65").Modify(); // serverhello tlsext
MemoryPatch::createWithHex("libTDataMaster.so", 0x2ECBB0, "73 73 6C 33 20 65 78 74").Modify(); // ssl3 ext invalid servername
MemoryPatch::createWithHex("libTDataMaster.so", 0x2ECBD0, "73 73 6C 33 20 65 78 74").Modify(); // ssl3 ext invalid servername type
MemoryPatch::createWithHex("libTDataMaster.so", 0x2ED7D8, "73 65 72 76 65 72 20 77").Modify(); // server write key
MemoryPatch::createWithHex("libTDataMaster.so", 0x2ED850, "73 65 72 76 65 72 20 66").Modify(); // server finished
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FB6E0, "6E 73 53 73 6C 53 65 72").Modify(); // nsSslServerName
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FB6F0, "4E 65 74 73 63 61 70 65").Modify(); // Netscape SSL Server Name
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FBCD0, "73 65 72 76 65 72 41 75").Modify(); // serverAuth
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FBCE0, "54 4C 53 20 57 65 62 20").Modify(); // TLS Web Server Authentication
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FBE40, "4D 69 63 72 6F 73 6F 66").Modify(); // Microsoft Server Gated Crypto
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FBE90, "4E 65 74 73 63 61 70 65").Modify(); // Netscape Server Gated Crypto
MemoryPatch::createWithHex("libTDataMaster.so", 0x3049E8, "73 65 72 76 65 72 20 72").Modify(); // server read error
MemoryPatch::createWithHex("libTDataMaster.so", 0x304A00, "73 65 72 76 65 72 20 72").Modify(); // server response error
MemoryPatch::createWithHex("libTDataMaster.so", 0x304A18, "73 65 72 76 65 72 20 72").Modify(); // server response parse error
MemoryPatch::createWithHex("libTDataMaster.so", 0x304A38, "73 65 72 76 65 72 20 77").Modify(); // server write error
MemoryPatch::createWithHex("libTDataMaster.so", 0x30B320, "53 53 4C 20 53 65 72 76").Modify(); // SSL Server
MemoryPatch::createWithHex("libTDataMaster.so", 0x30B370, "54 53 41 20 73 65 72 76").Modify(); // TSA server
MemoryPatch::createWithHex("libTDataMaster.so", 0x30C078, "73 73 6C 5F 73 65 72 76").Modify(); // ssl_server
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D770, "53 53 4C 20 73 65 72 76").Modify(); // SSL server
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D780, "73 73 6C 73 65 72 76 65").Modify(); // sslserver
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D790, "4E 65 74 73 63 61 70 65").Modify(); // Netscape SSL server
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D7A8, "6E 73 73 73 6C 73 65 72").Modify(); // nssslserver
MemoryPatch::createWithHex("libTDataMaster.so", 0x31CCE0, "53 53 4C 20 53 65 72 76").Modify(); // SSL Server
MemoryPatch::createWithHex("libTDataMaster.so", 0x31CCF0, "73 65 72 76 65 72 00 00").Modify(); // server

// ========== Path ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DB8B0, "6D 5F 73 7A 46 69 6C 65").Modify(); // m_szFilePath
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DBA74, "47 65 74 4A 61 76 61 4C").Modify(); // GetJavaLocalPath
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DBAA8, "67 65 74 4C 6F 63 61 6C").Modify(); // getLocalPath
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E14C0, "70 61 74 68 00 00 00 00").Modify(); // path
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E26E0, "55 6E 69 78 20 73 6F 63").Modify(); // Unix socket path too long: '%s'
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EC680, "70 61 74 68 20 74 6F 6F").Modify(); // path too long
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EFE18, "70 61 74 68 00 00 00 00").Modify(); // path
MemoryPatch::createWithHex("libTDataMaster.so", 0x2EFE40, "2C 20 70 61 74 68 3D 00").Modify(); // , path=
MemoryPatch::createWithHex("libTDataMaster.so", 0x2F69D8, "64 79 6E 61 6D 69 63 5F").Modify(); // dynamic_path
MemoryPatch::createWithHex("libTDataMaster.so", 0x2F69F0, "53 4F 5F 50 41 54 48 00").Modify(); // SO_PATH
MemoryPatch::createWithHex("libTDataMaster.so", 0x2FD5F0, "70 61 74 68 00 00 00 00").Modify(); // path
MemoryPatch::createWithHex("libTDataMaster.so", 0x30B738, "70 61 74 68 20 6C 65 6E").Modify(); // path length constraint exceeded
MemoryPatch::createWithHex("libTDataMaster.so", 0x30B758, "70 72 6F 78 79 20 70 61").Modify(); // proxy path length constraint exceeded
MemoryPatch::createWithHex("libTDataMaster.so", 0x30BB90, "43 52 4C 20 70 61 74 68").Modify(); // CRL path validation error
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D2A0, "25 2A 73 50 61 74 68 20").Modify(); // %*sPath Length Constraint:
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D3B8, "70 61 74 68 6C 65 6E 00").Modify(); // pathlen
MemoryPatch::createWithHex("libTDataMaster.so", 0x30D410, "70 63 50 61 74 68 4C 65").Modify(); // pcPathLengthConstraint
MemoryPatch::createWithHex("libTDataMaster.so", 0x30E160, "56 33 5F 41 44 44 52 5F").Modify(); // V3_ADDR_VALIDATE_PATH_INTERNAL
MemoryPatch::createWithHex("libTDataMaster.so", 0x30E7D0, "70 6F 6C 69 63 79 20 70").Modify(); // policy path length
MemoryPatch::createWithHex("libTDataMaster.so", 0x30E7E8, "70 6F 6C 69 63 79 20 70").Modify(); // policy path length already defined
MemoryPatch::createWithHex("libTDataMaster.so", 0x3196D0, "44 53 4F 5F 70 61 74 68").Modify(); // DSO_pathbyaddr
MemoryPatch::createWithHex("libTDataMaster.so", 0x319738, "50 41 54 48 42 59 41 44").Modify(); // PATHBYADDR
MemoryPatch::createWithHex("libTDataMaster.so", 0x319820, "57 49 4E 33 32 5F 50 41").Modify(); // WIN32_PATHBYADDR
MemoryPatch::createWithHex("libTDataMaster.so", 0x31CC08, "70 61 74 68 6C 65 6E 00").Modify(); // pathlen

// ========== aLog ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DBA20, "53 65 74 4A 61 76 61 4C").Modify(); // SetJavaLogLevel
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DBA30, "54 53 79 73 74 65 6D 3A").Modify(); // TSystem::SetJavaLogLevel tmpObj == 0

// ========== tdm_report ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DC8, "74 64 6D 5F 72 65 70 6F").Modify(); // tdm_report_login
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E6C, "54 44 4D 5F 52 65 70 6F").Modify(); // TDM_Report_Binary
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD9AC, "74 64 6D 5F 72 65 70 6F").Modify(); // tdm_report_event, data is null.

// ========== REPORT ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x26F0, "4A 61 76 61 5F 63 6F 6D").Modify(); // Java_com_tdatamaster_tdm_TDataMaster_TDMEnableReport
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DC8, "74 64 6D 5F 72 65 70 6F").Modify(); // tdm_report_login
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E6C, "54 44 4D 5F 52 65 70 6F").Modify(); // TDM_Report_Binary
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E90, "5F 5A 4E 36 47 43 6C 6F").Modify(); // _ZN6GCloud6Plugin12PluginReport10OnShutdownEv
MemoryPatch::createWithHex("libTDataMaster.so", 0x2F20, "5F 5A 4E 36 47 43 6C 6F").Modify(); // _ZN6GCloud6Plugin12PluginReport16GetServiceByNameEPKc
MemoryPatch::createWithHex("libTDataMaster.so", 0x3010, "5F 5A 4E 4B 36 47 43 6C").Modify(); // _ZNK6GCloud6Plugin12PluginReport7GetNameEv
MemoryPatch::createWithHex("libTDataMaster.so", 0x30B4, "5F 5A 54 68 6E 38 5F 4E").Modify(); // _ZThn8_N6GCloud6Plugin12PluginReport13OnPostStartupEv
MemoryPatch::createWithHex("libTDataMaster.so", 0x3120, "5F 5A 54 68 6E 38 5F 4E").Modify(); // _ZThn8_N6GCloud6Plugin12PluginReport16GetServiceByNameEPKc
MemoryPatch::createWithHex("libTDataMaster.so", 0x31CC, "5F 5A 54 68 6E 38 5F 4E").Modify(); // _ZThn8_N6GCloud6Plugin12PluginReportD1Ev
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D787C, "52 65 70 6F 72 74 20 6D").Modify(); // Report mode : %d
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7A0C, "52 65 70 6F 72 74 53 74").Modify(); // ReportStartup
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7D20, "52 65 70 6F 72 74 20 6C").Modify(); // Report login user event, platform:%d, openid:%s
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7E70, "4E 33 54 44 4D 31 33 45").Modify(); // N3TDM13EventReporterE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D7EB0, "4E 33 54 44 4D 31 34 49").Modify(); // N3TDM14IEventReporterE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D85B4, "68 74 74 70 20 72 65 70").Modify(); // http report is not enable
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D861C, "69 73 5F 63 6F 6D 70 72").Modify(); // is_compress_report
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D86D0, "72 65 70 6F 72 74 5F 69").Modify(); // report_interval
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D8BF8, "6E 6F 74 68 69 6E 67 20").Modify(); // nothing to report
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9244, "47 65 74 46 69 6C 65 4E").Modify(); // GetFileNameForReport
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9304, "2F 55 73 65 72 73 2F 69").Modify(); // /Users/intl/devops/PUBGM/TDMWorkspace/tdm/Project/TDM/Source/TDataMasterReporter.cpp
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9448, "72 65 70 6F 72 74 2D 62").Modify(); // report-bin
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9504, "72 65 70 6F 72 74 20 73").Modify(); // report success--------------------------------------
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D95D4, "2F 55 73 65 72 73 2F 69").Modify(); // /Users/intl/devops/PUBGM/TDMWorkspace/tdm/Project/TDM/Source/TDataMasterReportManager.cpp
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9840, "4F 6E 48 54 54 50 52 65").Modify(); // OnHTTPReportResp
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D98C8, "48 54 54 50 20 72 65 70").Modify(); // HTTP report error, error code : %d, error msg : %s
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9924, "48 54 54 50 20 72 65 70").Modify(); // HTTP report success
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9938, "68 74 74 70 20 72 65 70").Modify(); // http report success but delete file error
MemoryPatch::createWithHex("libTDataMaster.so", 0x2D9D28, "63 6F 6D 2F 74 64 61 74").Modify(); // com/tdatamaster/tdm/gcloud/service/PluginReportService
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DAE74, "5B 54 44 4D 20 48 54 54").Modify(); // [TDM HTTP] httpclient Create Request Thread Report Type is none
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD1D4, "4A 4E 49 20 54 44 4D 45").Modify(); // JNI TDMEnableReport %s
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD3D8, "4A 4E 49 20 54 44 4D 52").Modify(); // JNI TDMReportBinary, data is null!
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD8EC, "74 64 6D 5F 65 6E 61 62").Modify(); // tdm_enable_report
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DD9AC, "74 64 6D 5F 72 65 70 6F").Modify(); // tdm_report_event, data is null.
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDC00, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin12PluginReportE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDC20, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin9SingletonINS0_12PluginReportEEE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDD48, "52 65 70 6F 72 74 53 65").Modify(); // ReportService::GetSessionID
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDD64, "52 65 70 6F 72 74 53 65").Modify(); // ReportService::GetTDMUID
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DDFF0, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin13ReportServiceE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DE030, "4E 36 47 43 6C 6F 75 64").Modify(); // N6GCloud6Plugin14IReportServiceE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2DF9D0, "4E 33 54 44 4D 31 39 54").Modify(); // N3TDM19TDMDeviceReportTaskE
MemoryPatch::createWithHex("libTDataMaster.so", 0x2E3E78, "43 61 6E 27 74 20 63 6F").Modify(); // Can't complete SOCKS4 connection to %d.%d.%d.%d:%d. (%d), request rejected because the client program and identd report different user-ids.
MemoryPatch::createWithHex("libTDataMaster.so", 0x324EC0, "6E 6F 74 20 65 6E 6F 75").Modify(); // not enough space for format expansion (Please submit full bug report at http://gcc.gnu.org/bugs.html):

// ========== verify_signature ==========
MemoryPatch::createWithHex("libTDataMaster.so", 0x30A0C8, "54 53 5F 52 45 53 50 5F").Modify(); // TS_RESP_verify_signature
